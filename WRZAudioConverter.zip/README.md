# WRZ Media 2.0

原生 Android + Jetpack Compose + FFmpegKit + Media3。

## 当前功能
- 音频批量转换与文件夹递归扫描
- 视频批量转换：H.264 / H.265 / 原视频流复制
- MP4 音视频合并：视频流默认 copy，音频 AAC
- 本地视频预览与原始媒体参数查看
- Android 前台 mediaProcessing 服务后台转码
- 持续通知进度
- 小米 HyperOS 超级岛扩展参数兼容钩子
- 不要求账号，不上传媒体文件

## 构建
GitHub Actions 使用 JDK 17 + Gradle 8.10.2，工作流会自动生成 Gradle Wrapper。


### Android 17 compatibility
- compileSdk 37 / targetSdk 37
- minSdk remains 24
- Android 15+ uses the explicit `mediaProcessing` foreground-service type.
- Older Android versions keep the two-argument foreground-service startup path.
- Media-processing timeout is handled with `Service.onTimeout(startId, fgsType)`.
