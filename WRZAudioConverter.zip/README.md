# WRZ Audio Converter

原生 Android 批量音频转换器。

## 功能

- 系统文件选择器批量选择音频
- 本地 FFmpeg 转换，不上传文件
- 输出 MP3 / M4A / AAC / WAV / FLAC / OGG / OPUS
- MP3、M4A、AAC、OGG、OPUS 可调比特率
- 自动避免覆盖同名文件
- Android 7.0+（API 24+）

## 技术栈

- Kotlin
- Jetpack Compose
- Android SDK 35
- FFmpegKit maintained 8.1.9

依赖：

```kotlin
implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.9")
```

FFmpegKit 原项目已经退休；本项目使用社区维护的 Android 延续版。

## 手机构建

最简单的方式是把项目上传到 GitHub，然后使用 GitHub Actions/云端 Android 构建环境生成 APK。

本项目只需要 Android Gradle Plugin、Kotlin 和 Maven Central，不需要把 FFmpeg 源码放进仓库。
