# WRZ Media 2.0

原生 Android + Jetpack Compose + FFmpegKit + Media3。

## 当前功能
- 音频批量转换与文件夹递归扫描
- 视频批量转换：H.264 / H.265 / 原视频流复制
- MP4 音视频合并：视频流默认 copy，音频 AAC
- 本地视频预览与原始媒体参数查看
- Android 前台 mediaProcessing 服务后台转码
- 持续通知进度
- 小米 HyperOS 超级岛扩展参数兼容钩子
- 不要求账号，不上传媒体文件

## 构建
GitHub Actions 使用 JDK 17 + Gradle 8.10.2，工作流会自动生成 Gradle Wrapper。


Video hardware encoding fix: MediaCodec now uses NDK mode and lets FFmpeg select the platform encoder by MIME instead of forcing a vendor codec name.

## 视频速度优化（当前版）
- H.264 / H.265 优先使用 Android MediaCodec 硬件编码，并使用 NDK MediaCodec。
- 对兼容的视频输入先尝试 MediaCodec 硬件解码 + 硬件编码链路。
- 硬件解码链路失败会自动回退到兼容的硬件编码路径。
- 硬件编码仍失败时，H.264 / H.265 自动回退 CPU 编码，避免任务直接失败。
- 视频自动并行默认最多 2 路，避免多个硬件编码实例争抢移动端编解码资源；手动设置的视频并行也限制为最多 2 路。
