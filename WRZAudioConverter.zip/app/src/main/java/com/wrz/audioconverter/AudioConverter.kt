package com.wrz.audioconverter

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.Statistics
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class AudioConverter(val context: Context) {
    val scope = CoroutineScope(Dispatchers.Main)

    suspend fun convertBatch(
        files: List<AudioItem>,
        outputFormat: String,
        bitrate: Int,
        outputTree: Uri,
        onProgress: (index: Int, total: Int, name: String, progress: Int, state: String) -> Unit
    ): String = withContext(Dispatchers.IO) {
        var success = 0
        files.forEachIndexed { index, item ->
            onProgress(index, files.size, item.name, 0, "准备中")
            try {
                val input = copyUriToCache(item.uri, "input_$index")
                val ext = outputFormat.lowercase(Locale.US)
                val base = item.name.substringBeforeLast('.', item.name)
                val safeBase = base.ifBlank { "audio_$index" }
                val outFile = File(context.cacheDir, "output_$index.$ext")

                val command = buildCommand(input.absolutePath, outFile.absolutePath, ext, bitrate)

                val session = FFmpegKit.execute(command)
                if (ReturnCode.isSuccess(session.returnCode)) {
                    copyFileToTree(outFile, outputTree, "$safeBase.$ext")
                    success++
                    onProgress(index, files.size, item.name, 100, "转换完成")
                } else {
                    onProgress(index, files.size, item.name, 0, "转换失败")
                }

                input.delete()
                outFile.delete()
            } catch (e: Exception) {
                onProgress(index, files.size, item.name, 0, "失败：${e.message ?: "未知错误"}")
            }
        }
        "完成：$success / ${files.size} 个文件转换成功"
    }

    private fun buildCommand(input: String, output: String, ext: String, bitrate: Int): String {
        val i = quote(input)
        val o = quote(output)
        return when (ext) {
            "mp3" -> "-y -i $i -vn -c:a libmp3lame -b:a ${bitrate}k $o"
            "m4a", "aac" -> "-y -i $i -vn -c:a aac -b:a ${bitrate}k $o"
            "ogg" -> "-y -i $i -vn -c:a libvorbis -b:a ${bitrate}k $o"
            "opus" -> "-y -i $i -vn -c:a libopus -b:a ${bitrate}k $o"
            "flac" -> "-y -i $i -vn -c:a flac $o"
            "wav" -> "-y -i $i -vn -c:a pcm_s16le $o"
            else -> throw IllegalArgumentException("不支持的输出格式：$ext")
        }
    }

    private fun quote(path: String): String =
        "'" + path.replace("'", "'\\''") + "'"

    private fun copyUriToCache(uri: Uri, name: String): File {
        val ext = context.contentResolver.query(
            uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
        )?.use { c ->
            if (c.moveToFirst()) c.getString(0).substringAfterLast('.', "bin") else "bin"
        } ?: "bin"

        val file = File(context.cacheDir, "$name.$ext")
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "无法读取文件" }
            file.outputStream().use { output -> input.copyTo(output) }
        }
        return file
    }

    private fun copyFileToTree(file: File, treeUri: Uri, name: String) {
        val tree = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("输出文件夹不可用")

        var targetName = name
        var n = 1
        while (tree.findFile(targetName) != null) {
            val dot = name.lastIndexOf('.')
            targetName = if (dot > 0)
                "${name.substring(0, dot)} ($n)${name.substring(dot)}"
            else
                "$name ($n)"
            n++
        }

        val target = tree.createFile(mimeFor(name), targetName)
            ?: throw IllegalStateException("无法创建输出文件")

        context.contentResolver.openOutputStream(target.uri).use { out ->
            requireNotNull(out)
            file.inputStream().use { input -> input.copyTo(out) }
        }
    }

    private fun mimeFor(name: String): String = when {
        name.endsWith(".mp3", true) -> "audio/mpeg"
        name.endsWith(".m4a", true) -> "audio/mp4"
        name.endsWith(".aac", true) -> "audio/aac"
        name.endsWith(".wav", true) -> "audio/wav"
        name.endsWith(".flac", true) -> "audio/flac"
        name.endsWith(".ogg", true) -> "audio/ogg"
        name.endsWith(".opus", true) -> "audio/opus"
        else -> "application/octet-stream"
    }
}
