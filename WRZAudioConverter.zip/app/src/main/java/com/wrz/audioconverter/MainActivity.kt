package com.wrz.audioconverter

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

data class AudioItem(
    val uri: Uri,
    val name: String,
    val state: String = "待转换",
    val progress: Int = 0
)

class MainActivity : ComponentActivity() {
    private val converter by lazy { AudioConverter(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                AudioConverterScreen(converter)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioConverterScreen(converter: AudioConverter) {
    var files by remember { mutableStateOf(listOf<AudioItem>()) }
    var outputFormat by remember { mutableStateOf("MP3") }
    var bitrate by remember { mutableStateOf(192) }
    var outputTree by remember { mutableStateOf<Uri?>(null) }
    var running by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("准备就绪") }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val newItems = uris.mapNotNull { uri ->
            val name = displayName(converter.context.contentResolver, uri) ?: return@mapNotNull null
            AudioItem(uri, name)
        }
        files = (files + newItems).distinctBy { it.uri.toString() }
    }

    val folderPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        outputTree = uri
        if (uri != null) {
            try {
                converter.context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {}
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("WRZ Audio Converter") })
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { picker.launch(arrayOf("audio/*")) },
                        modifier = Modifier.weight(1f)
                    ) { Text("＋ 添加音频") }

                    OutlinedButton(
                        onClick = { files = emptyList() },
                        enabled = files.isNotEmpty()
                    ) { Text("清空") }
                }
            }

            item {
                Text("已添加 ${files.size} 个文件", style = MaterialTheme.typography.titleMedium)
            }

            items(files, key = { it.uri.toString() }) { item ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(item.name)
                        Spacer(Modifier.height(4.dp))
                        Text(item.state, style = MaterialTheme.typography.bodySmall)
                        if (item.progress > 0 && item.progress < 100) {
                            LinearProgressIndicator(
                                progress = { item.progress / 100f },
                                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                            )
                        }
                    }
                }
            }

            item {
                HorizontalDivider()
                Text("输出格式", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))

                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = outputFormat,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("格式") },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        listOf("MP3", "M4A", "AAC", "WAV", "FLAC", "OGG", "OPUS").forEach { f ->
                            DropdownMenuItem(
                                text = { Text(f) },
                                onClick = {
                                    outputFormat = f
                                    expanded = false
                                }
                            )
                        }
                    }
                }
            }

            item {
                Text("比特率：${bitrate} kbps", style = MaterialTheme.typography.titleMedium)
                Slider(
                    value = bitrate.toFloat(),
                    onValueChange = { bitrate = (it / 16).toInt() * 16 },
                    valueRange = 64f..320f,
                    steps = 15
                )
                Text(
                    if (outputFormat in listOf("WAV", "FLAC"))
                        "当前格式通常不使用 MP3 式比特率压缩。"
                    else
                        "比特率越低，文件通常越小；有损格式会有一定音质损失。",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            item {
                OutlinedButton(
                    onClick = { folderPicker.launch(null) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(outputTree?.let { "已选择输出文件夹" } ?: "选择输出文件夹")
                }
            }

            item {
                Button(
                    enabled = files.isNotEmpty() && outputTree != null && !running,
                    onClick = {
                        running = true
                        status = "正在批量转换…"
                        converter.scope.launch {
                            val result = converter.convertBatch(
                                files = files,
                                outputFormat = outputFormat,
                                bitrate = bitrate,
                                outputTree = outputTree!!
                            ) { index, total, name, progress, state ->
                                files = files.mapIndexed { i, old ->
                                    if (i == index) old.copy(state = state, progress = progress) else old
                                }
                                status = "$index / $total：$name"
                            }
                            status = result
                            running = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(if (running) "转换中…" else "开始批量转换")
                }
            }

            item {
                Text(status, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

fun displayName(resolver: ContentResolver, uri: Uri): String? {
    resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) return c.getString(0)
    }
    return uri.lastPathSegment
}
