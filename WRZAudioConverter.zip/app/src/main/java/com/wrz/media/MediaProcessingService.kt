package com.wrz.media

import android.app.*
import android.content.*
import android.net.Uri
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.Statistics
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

class MediaProcessingService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val sessions = ConcurrentHashMap<Long, FFmpegSession>()
    private val outputLock = Any()
    private val activeProgress = ConcurrentHashMap<Int, Int>()
    private val lastErrorByFile = ConcurrentHashMap<Int, String>()
    private val lastProgressEmit = AtomicLong(0L)
    @Volatile private var cancelled = false
    @Volatile private var paused = false
    @Volatile private var pauseRequested = false
    @Volatile private var smoothProgress = 0
    @Volatile private var accelerationMode = ""
    @Volatile private var lastFps: Double = 0.0
    @Volatile private var lastSpeed: String = ""
    private var currentTask: TaskData? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                cancelled = true
                paused = false
                cancelSessions()
                clearSavedTask()
                update("WRZ Media", 0, "任务已取消", true, taskMode = currentTask?.mode ?: "")
                stopNow()
            }
            ACTION_PAUSE -> {
                // 即使 Service 被系统重建，也能从已保存任务恢复暂停状态。
                val task = currentTask ?: loadSavedTask()
                if (task != null && !paused) {
                    currentTask = task
        accelerationMode = ""
                    paused = true
                    pauseRequested = true
                    cancelled = false
                    saveTask(task)
                    savePaused(true)
                    // 先广播暂停状态，再终止 FFmpeg，避免 UI 一直停留在“暂停”按钮。
                    update(task.title, progressValue, "已暂停 · 断点已保存", false, taskMode = task.mode, paused = true, completed = loadCompleted(), total = task.uris.size)
                    cancelSessions()
                }
            }
            ACTION_RESUME -> {
                val task = loadSavedTask() ?: TaskData.fromIntent(intent)
                if (task != null) {
                    startTask(task, resume = true)
                } else if (task == null) {
                    sendStatus(0, "没有可恢复的任务", true, "", error = true)
                }
            }
            ACTION_START -> {
                val task = TaskData.fromIntent(intent)
                if (task == null) {
                    sendStatus(0, "任务参数无效，无法启动", true, "", error = true)
                    stopSelf()
                } else startTask(task, resume = false)
            }
        }
        return START_NOT_STICKY
    }

    private fun startTask(task: TaskData, resume: Boolean) {
        cancelled = false
        paused = false
        pauseRequested = false
        currentTask = task
        if (!resume) smoothProgress = 0
        if (resume) smoothProgress = progressValue.coerceIn(0, 99)
        if (!resume) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_COMPLETED).remove(KEY_PAUSED).apply()
            saveTask(task)
        } else {
            savePaused(false)
        }
        try {
            startAsForeground(task.title)
            update(task.title, if (resume) progressValue else 0, if (resume) "正在恢复任务…" else "任务已启动，正在读取文件…", false, task.mode)
        } catch (e: Throwable) {
            val message = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
            sendStatus(0, "后台任务启动失败：$message", true, task.mode, error = true)
            return
        }
        scope.launch {
            try {
                when (task.mode) {
                    "audio" -> processBatch(task, ::audioCommand)
                    "video" -> processBatch(task, ::videoCommand)
                    "merge" -> processMerge(task)
                    else -> error("未知任务类型：${task.mode}")
                }
            } catch (e: CancellationException) {
                if (!paused && !cancelled) update(task.title, 0, "任务已停止", true, task.mode)
            } catch (e: Exception) {
                val message = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
                update(task.title, progressValue, "失败：$message", true, task.mode, error = true)
            } finally {
                if (!paused && !cancelled) {
                    clearSavedTask()
                    stopNow()
                }
            }
        }
    }

    private fun startAsForeground(title: String) {
        val notification = buildNotification(title, 0, "准备中", false)
        if (Build.VERSION.SDK_INT >= 35) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING)
        } else if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else startForeground(NOTIFICATION_ID, notification)
    }

    private suspend fun processBatch(task: TaskData, commandBuilder: (String, String, TaskData) -> String) = coroutineScope {
        val completed: MutableSet<Int> = java.util.Collections.synchronizedSet(loadCompleted().toMutableSet())
        val total = task.uris.size
        if (total == 0) error("没有可转换的文件")
        val workers = parallelWorkers(task)
        activeProgress.clear()
        lastErrorByFile.clear()
        update(task.title, overallProgress(completed, total), "队列 ${total - completed.size} 个 · 并行 ${workers} 路", false, task.mode, completed = completed, total = total)

        val queue = task.uris.indices.filter { it !in completed }
        val cursor = java.util.concurrent.atomic.AtomicInteger(0)
        val failed = java.util.concurrent.atomic.AtomicInteger(0)
        val jobs = List(minOf(workers, queue.size)) {
            launch(Dispatchers.IO) {
                while (true) {
                    if (cancelled || paused) return@launch
                    val pos = cursor.getAndIncrement()
                    if (pos >= queue.size) return@launch
                    val index = queue[pos]
                    val uri = Uri.parse(task.uris[index])
                    val name = task.names.getOrNull(index) ?: "media_$index"
                    var input: File? = null
                    var output: File? = null
                    try {
                        activeProgress[index] = 0
                        update(task.title, overallProgress(completed, total), "处理中：$name", false, task.mode, completed = completed, currentIndex = index, total = total)
                        input = copyToCache(uri, "wrz_input_${System.currentTimeMillis()}_$index")
                        val ext = if (task.mode == "audio") task.outputExt.lowercase(Locale.US) else task.videoExt.lowercase(Locale.US)
                        val base = name.substringBeforeLast('.', name).ifBlank { "media_$index" }
                        output = File(cacheDir, "wrz_output_${System.currentTimeMillis()}_$index.$ext")
                        if (pauseRequested || paused || cancelled) return@launch
                        var session = if (task.mode == "video") {
                            executeVideoWithFallback(input, output, task, name, index, total, completed)
                        } else {
                            val command = commandBuilder(input.absolutePath, output.absolutePath, task)
                            executeWithProgress(command, task.title, name, index, total, input, completed)
                        }
                        if (paused || cancelled) return@launch
                        if (ReturnCode.isSuccess(session.returnCode)) {
                            synchronized(outputLock) {
                                copyToTree(output, Uri.parse(task.outputTree), uniqueName(Uri.parse(task.outputTree), "$base.$ext"))
                                completed += index
                                saveCompleted(completed)
                            }
                            activeProgress.remove(index)
                            update(task.title, overallProgress(completed, total), "完成：$name · ${completed.size}/$total", false, task.mode, completed = completed, currentIndex = index, currentFileProgress = 100, total = total)
                        } else {
                            failed.incrementAndGet()
                            activeProgress.remove(index)
                            val detail = failureDetail(session)
                            lastErrorByFile[index] = detail
                            update(task.title, smoothProgress, "失败：$name · ${detail.take(220)}", false, task.mode, completed = completed, currentIndex = index, total = total)
                        }
                    } catch (e: CancellationException) {
                        return@launch
                    } catch (e: Exception) {
                        failed.incrementAndGet()
                        activeProgress.remove(index)
                        val detail = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
                        lastErrorByFile[index] = detail
                        update(task.title, smoothProgress, "失败：$name · ${detail.take(220)}", false, task.mode, completed = completed, currentIndex = index, total = total)
                    } finally {
                        input?.delete(); output?.delete()
                    }
                }
            }
        }
        jobs.joinAll()
        if (!paused && !cancelled) {
            if (completed.size == total) {
                update(task.title, 100, "全部完成：$total / $total", true, task.mode, completed = completed, total = total)
            } else {
                saveTask(task)
                val reason = lastErrorByFile.values.firstOrNull()?.take(260)
                val suffix = if (reason != null) "；最近失败原因：$reason" else ""
                update(task.title, overallProgress(completed, total), "完成 ${completed.size}/$total，失败 ${failed.get()} 个；可继续重试$suffix", true, task.mode, error = failed.get() > 0, completed = completed, total = total)
            }
        }
    }

    private suspend fun processMerge(task: TaskData) {
        val video = copyToCache(Uri.parse(task.uris[0]), "wrz_merge_video_${System.currentTimeMillis()}")
        val audio = copyToCache(Uri.parse(task.uris[1]), "wrz_merge_audio_${System.currentTimeMillis()}")
        val output = File(cacheDir, "wrz_merge_${System.currentTimeMillis()}.mp4")
        try {
            update(task.title, 0, "正在合并", false, task.mode)
            // Merge audio follows an explicit user choice. Lossy sources are never offered FLAC in the UI.
            val audioName = task.names.getOrNull(1) ?: ""
            val isFlac = audioName.substringAfterLast('.', "").equals("flac", ignoreCase = true)
            val audioArgs = when (task.mergeAudioCodec.lowercase()) {
                "original" -> "-c:a copy"
                "flac" -> if (isFlac) "-c:a flac" else "-c:a aac -profile:a aac_low -ar 48000 -b:a ${task.bitrate}k"
                else -> "-c:a aac -profile:a aac_low -ar 48000 -b:a ${task.bitrate}k"
            }
            val command = "-y -i ${quote(video.absolutePath)} -i ${quote(audio.absolutePath)} -map 0:v:0 -map 1:a:0 -c:v copy $audioArgs -movflags +faststart -shortest ${quote(output.absolutePath)}"
            val session = executeWithProgress(command, task.title, task.names.getOrNull(0) ?: "合并", 0, 1, video)
            if (!paused && !cancelled && ReturnCode.isSuccess(session.returnCode)) {
                copyToTree(output, Uri.parse(task.outputTree), uniqueName(Uri.parse(task.outputTree), task.mergeName.ifBlank { "merged.mp4" }))
                update(task.title, 100, "合并完成", true, task.mode)
            } else if (!paused && !cancelled) {
                val detail = failureDetail(session)
                update(task.title, 0, "合并失败：$detail", true, task.mode)
            } else if (paused) {
                saveTask(task)
            }
        } finally { video.delete(); audio.delete(); output.delete() }
    }

    private suspend fun executeWithProgress(command: String, title: String, name: String, index: Int, total: Int, input: File, completed: Set<Int> = emptySet()): FFmpegSession = suspendCancellableCoroutine { cont ->
        val duration = mediaDurationMs(input)
        try {
            val session = FFmpegKit.executeAsync(command, { result ->
                sessions.remove(result.sessionId)
                if (!cont.isCompleted) cont.resume(result)
            }, { log ->
                if (!paused && !cancelled && log.message.contains("Error", ignoreCase = true)) update(title, progressValue, "FFmpeg：${log.message.take(160)}", false, currentTask?.mode ?: "")
            }, { stats: Statistics ->
                if (!paused && !cancelled) {
                    val reported = if (duration > 0) ((stats.time.toDouble() / duration) * 100).coerceIn(0.0, 100.0).toInt() else 0
                    val fileProgress = maxOf(activeProgress[index] ?: 0, reported)
                    activeProgress[index] = fileProgress
                    val activeSum = activeProgress.values.sum().coerceAtMost(total * 100)
                    val target = (((completed.size * 100L + activeSum) / total).toInt()).coerceIn(0, 99)
                    // 先算出真实目标，再限制单次视觉变化，避免多路 FFmpeg 的统计回调造成进度条瞬移。
                    val now = System.currentTimeMillis()
                    val old = smoothProgress
                    val step = if (target > old) minOf(target, old + 2) else old
                    smoothProgress = maxOf(old, step)
                    progressValue = smoothProgress
                    val fps = runCatching { stats.videoFps.toDouble() }.getOrDefault(0.0)
                    val speed = runCatching { stats.speed }.getOrDefault(0.0)
                    if (fps > 0.0) lastFps = fps
                    if (speed > 0.0) lastSpeed = "%.2fx".format(Locale.US, speed)
                    if (now - lastProgressEmit.get() >= 180L || fileProgress >= 99) {
                        lastProgressEmit.set(now)
                        val workers = currentTask?.let { parallelWorkers(it) } ?: 1
                        val telemetry = buildString {
                            if (total > 1 && workers > 1) append("并行处理中：$name · $fileProgress% · ${workers} 路")
                            else append("处理中：$name · $fileProgress%")
                            if (lastFps > 0.0) append(" · %.1f FPS".format(Locale.US, lastFps))
                            if (lastSpeed.isNotBlank()) append(" · $lastSpeed")
                        }
                        update(title, smoothProgress, telemetry, false, currentTask?.mode ?: "", completed = completed, currentIndex = index, currentFileProgress = fileProgress, total = total)
                    }
                }
            })
            sessions[session.sessionId] = session
            if (pauseRequested || paused || cancelled) {
                try { FFmpegKit.cancel(session.sessionId) } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            if (!cont.isCompleted) cont.resumeWithException(e)
        }
        cont.invokeOnCancellation { sessions.values.forEach { FFmpegKit.cancel(it.sessionId) } }
    }

    private fun failureDetail(session: FFmpegSession): String {
        val stack = session.failStackTrace?.lineSequence()?.filter { it.isNotBlank() }?.toList()?.takeLast(4)?.joinToString(" | ")
        if (!stack.isNullOrBlank()) return stack
        val output = session.output?.lineSequence()?.filter { it.isNotBlank() }?.toList()?.takeLast(6)?.joinToString(" | ")
        if (!output.isNullOrBlank()) return output
        return "FFmpeg 返回码：${session.returnCode}"
    }

    private fun audioCommand(input: String, output: String, task: TaskData): String {
        val i = quote(input); val o = quote(output); val b = task.bitrate
        val threads = if (parallelWorkers(task) > 1) 1 else 0
        return when (task.outputExt.lowercase(Locale.US)) {
            "mp3" -> "-y -threads $threads -i $i -vn -c:a libmp3lame -b:a ${b}k $o"
            "m4a" -> "-y -threads $threads -i $i -vn -c:a aac -b:a ${b}k -movflags +faststart $o"
            "aac" -> "-y -threads $threads -i $i -vn -c:a aac -b:a ${b}k $o"
            "ogg" -> "-y -threads $threads -i $i -vn -c:a libvorbis -b:a ${b}k $o"
            "opus" -> "-y -threads $threads -i $i -vn -c:a libopus -b:a ${b}k $o"
            "flac" -> "-y -threads $threads -i $i -vn -c:a flac $o"
            "wav" -> "-y -threads $threads -i $i -vn -c:a pcm_s16le $o"
            else -> error("不支持的音频输出格式")
        }
    }

    private fun aomSpeed(preset: String) = when (preset) { "ultrafast" -> 8; "fast" -> 6; "medium" -> 4; "slow" -> 2; else -> 0 }
    private fun vpxDeadline(preset: String) = when (preset) { "ultrafast" -> "realtime"; "fast" -> "good"; "medium" -> "good"; "slow" -> "good"; else -> "best" }
    private fun mpeg2Quality(crf: Int) = ((crf - 10) / 2).coerceIn(2, 10)
    private fun hardwareBitrate(crf: Int, ext: String): Int = ((30 - crf) * 400 + 2000).coerceIn(1500, 20000)

    // MediaCodec: let FFmpeg choose the platform encoder by MIME instead of forcing a vendor codec name.
    // NDK MediaCodec avoids the Java MediaCodec released-state path seen on some recent Xiaomi/Qualcomm devices.
    private suspend fun executeVideoWithFallback(
        input: File,
        output: File,
        task: TaskData,
        name: String,
        index: Int,
        total: Int,
        completed: Set<Int>
    ): FFmpegSession {
        val codec = task.videoCodec
        val inputMime = videoMime(input)
        val hardwareDecoderCandidate = inputMime == "video/avc" || inputMime == "video/hevc" || inputMime == "video/av01" || inputMime == "video/x-vnd.on2.vp9" || inputMime == "video/x-vnd.on2.vp8"
        val wantsHardwareEncoder = codec == "H.264 / AVC" || codec == "H.265 / HEVC"
        if (wantsHardwareEncoder && hardwareDecoderCandidate) {
            accelerationMode = "⚡ 尝试：硬件解码 + 硬件编码"
            val fastCommand = videoCommand(input.absolutePath, output.absolutePath, task, hardwareDecode = true)
            val fastSession = executeWithProgress(fastCommand, task.title, name, index, total, input, completed)
            if (ReturnCode.isSuccess(fastSession.returnCode)) {
                accelerationMode = "⚡ 硬件解码 + 硬件编码"
                update(task.title, progressValue, "硬件解码 + 硬件编码", false, task.mode, completed = completed, currentIndex = index, total = total)
                return fastSession
            }
            if (paused || cancelled) return fastSession
            output.delete()
            accelerationMode = "⚡ 硬件编码 · 软件解码"
            update(task.title, progressValue, "硬件解码不可用，已回退软件解码 + 硬件编码…", false, task.mode, completed = completed, currentIndex = index, total = total)
        }
        if (wantsHardwareEncoder) accelerationMode = "⚡ 硬件编码 · 软件解码"
        val hardwareCommand = videoCommand(input.absolutePath, output.absolutePath, task, hardwareDecode = false)
        val hardwareSession = executeWithProgress(hardwareCommand, task.title, name, index, total, input, completed)
        if (ReturnCode.isSuccess(hardwareSession.returnCode)) {
            if (wantsHardwareEncoder) accelerationMode = "⚡ 硬件编码 · 软件解码"
            return hardwareSession
        }
        if (paused || cancelled) return hardwareSession
        if (codec == "H.264 / AVC" || codec == "H.265 / HEVC") {
            output.delete()
            accelerationMode = "CPU 软件解码 + CPU 软件编码"
            update(task.title, progressValue, "硬件编码不可用，正在回退 CPU 编码…", false, task.mode, completed = completed, currentIndex = index, total = total)
            val softwareCommand = videoCommand(input.absolutePath, output.absolutePath, task, hardwareDecode = false, forceSoftware = true)
            return executeWithProgress(softwareCommand, task.title, name, index, total, input, completed)
        }
        return hardwareSession
    }

    private fun videoMime(file: File): String? = try {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(file.absolutePath)
        val mime = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE)
        retriever.release()
        mime
    } catch (_: Throwable) { null }

    private fun videoCommand(input: String, output: String, task: TaskData, hardwareDecode: Boolean = false, forceSoftware: Boolean = false): String {
        val i = quote(input); val o = quote(output)
        val video = when (task.videoCodec) {
            "H.265 / HEVC" -> "hevc_mediacodec"
            "AV1" -> "libaom-av1"
            "VP9" -> "libvpx-vp9"
            "VP8" -> "libvpx"
            "MPEG-4" -> "mpeg4"
            "MPEG-2" -> "mpeg2video"
            "复制原视频流" -> "copy"
            else -> "h264_mediacodec"
        }
        val threads = if (parallelWorkers(task) > 1) 1 else 0
        val ext = task.videoExt.lowercase(Locale.US)
        val audioArgs = when (ext) {
            "webm" -> "-c:a libopus -b:a ${task.bitrate}k"
            else -> "-c:a aac -b:a ${task.bitrate}k"
        }
        val videoArgs = when (video) {
            "copy" -> "-c:v copy -c:a copy"
            "h264_mediacodec" -> if (forceSoftware) "-threads 0 -c:v libx264 -preset ${task.preset} -crf ${task.crf} -pix_fmt yuv420p $audioArgs" else "-c:v h264_mediacodec -ndk_codec 1 -bitrate_mode vbr -b:v ${hardwareBitrate(task.crf, ext)}k -g 120 -pix_fmt nv12 $audioArgs"
            "hevc_mediacodec" -> if (forceSoftware) "-threads 0 -c:v libx265 -preset ${task.preset} -crf ${task.crf} -pix_fmt yuv420p $audioArgs" else "-c:v hevc_mediacodec -ndk_codec 1 -bitrate_mode vbr -b:v ${hardwareBitrate(task.crf, ext)}k -g 120 -pix_fmt nv12 $audioArgs"
            "libaom-av1" -> "-threads $threads -c:v libaom-av1 -crf ${task.crf} -b:v 0 -cpu-used ${aomSpeed(task.preset)} -pix_fmt yuv420p $audioArgs"
            "libvpx-vp9" -> "-threads $threads -c:v libvpx-vp9 -crf ${task.crf} -b:v 0 -deadline ${vpxDeadline(task.preset)} -pix_fmt yuv420p $audioArgs"
            "libvpx" -> "-threads $threads -c:v libvpx -crf ${task.crf} -b:v 0 -deadline ${vpxDeadline(task.preset)} -pix_fmt yuv420p ${if (ext == "webm") "-c:a libvorbis -b:a ${task.bitrate}k" else audioArgs}"
            "mpeg2video" -> "-threads $threads -c:v mpeg2video -q:v ${mpeg2Quality(task.crf)} -pix_fmt yuv420p $audioArgs"
            else -> "-threads $threads -c:v $video -crf ${task.crf} -pix_fmt yuv420p $audioArgs"
        }
        val faststart = if (task.videoExt.lowercase(Locale.US) in setOf("mp4", "mov", "m4v")) "-movflags +faststart" else ""
        val hwDecodeArgs = if (hardwareDecode && !forceSoftware && video != "copy") "-hwaccel mediacodec -hwaccel_output_format mediacodec" else ""
        return "-y $hwDecodeArgs -i $i -map 0:v:0? -map 0:a:0? $videoArgs $faststart $o"
    }

    private fun copyToCache(uri: Uri, name: String): File {
        val displayName = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        val originalExt = displayName?.substringAfterLast('.', "")?.lowercase(Locale.US)
        val mimeExt = contentResolver.getType(uri)?.substringAfterLast('/')?.replace(Regex("[^A-Za-z0-9]"), "")
        val ext = when { !originalExt.isNullOrBlank() -> originalExt; !mimeExt.isNullOrBlank() -> mimeExt; else -> "bin" }
        val file = File(cacheDir, "$name.$ext")
        contentResolver.openInputStream(uri).use { input -> requireNotNull(input) { "无法读取输入文件" }; file.outputStream().buffered(1024 * 1024).use { output -> input.copyTo(output, 1024 * 1024) } }
        return file
    }

    private fun copyToTree(file: File, treeUri: Uri, name: String) {
        val tree = DocumentFile.fromTreeUri(this, treeUri) ?: error("输出目录不可用")
        val mime = when (name.substringAfterLast('.', "").lowercase()) { "mp4" -> "video/mp4"; "mkv" -> "video/x-matroska"; "webm" -> "video/webm"; "mov" -> "video/quicktime"; "avi" -> "video/x-msvideo"; "ts" -> "video/mp2t"; "mpg" -> "video/mpeg"; "flv" -> "video/x-flv"; "3gp" -> "video/3gpp"; "mp3" -> "audio/mpeg"; "wav" -> "audio/wav"; "flac" -> "audio/flac"; "m4a" -> "audio/mp4"; "aac" -> "audio/aac"; "ogg" -> "audio/ogg"; "opus" -> "audio/opus"; else -> "application/octet-stream" }
        val existing = tree.findFile(name)
        existing?.delete()
        tree.createFile(mime, name)?.let { dest ->
            contentResolver.openOutputStream(dest.uri).use { out ->
                requireNotNull(out)
                file.inputStream().buffered(1024 * 1024).use { it.copyTo(out, 1024 * 1024) }
            }
        } ?: error("无法创建输出文件")
    }

    private fun uniqueName(treeUri: Uri, desired: String): String = desired

    private fun mediaDurationMs(file: File): Long = try { val r = android.media.MediaMetadataRetriever(); r.setDataSource(file.absolutePath); val d = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0; r.release(); d } catch (_: Exception) { 0 }
    private fun quote(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun parallelWorkers(task: TaskData): Int {
        val pref = if (task.parallel > 0) task.parallel else getSharedPreferences("wrz_media_settings", MODE_PRIVATE).getInt("parallel", 0)
        if (pref > 0) return if (task.mode == "video") pref.coerceIn(1, 2) else pref.coerceIn(1, 8)
        val cores = Runtime.getRuntime().availableProcessors()
        return if (task.mode == "video") {
            when { cores >= 12 -> 2; else -> 1 }
        } else {
            when { cores >= 16 -> 8; cores >= 12 -> 6; cores >= 8 -> 4; cores >= 6 -> 3; cores >= 4 -> 2; else -> 1 }
        }
    }

    private fun cancelSessions() { sessions.values.forEach { try { FFmpegKit.cancel(it.sessionId) } catch (_: Exception) {} }; sessions.clear() }

    private fun overallProgress(done: Set<Int>, total: Int) = if (total == 0) 0 else (done.size * 100 / total).coerceIn(0, 99)

    private fun savePaused(value: Boolean) { getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_PAUSED, value).apply() }

    private fun saveTask(task: TaskData) { getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_TASK, task.toJson().toString()).apply() }
    private fun loadSavedTask(): TaskData? = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_TASK, null)?.let { runCatching { TaskData.fromJson(JSONObject(it)) }.getOrNull() }
    private fun clearSavedTask() { getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_TASK).remove(KEY_COMPLETED).remove(KEY_PAUSED).apply() }
    private fun saveCompleted(completed: Set<Int>) { getSharedPreferences(PREFS, MODE_PRIVATE).edit().putStringSet(KEY_COMPLETED, completed.map { it.toString() }.toSet()).apply() }
    private fun loadCompleted(): Set<Int> = getSharedPreferences(PREFS, MODE_PRIVATE).getStringSet(KEY_COMPLETED, emptySet())?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()

    private fun sendStatus(progress: Int, text: String, finished: Boolean, mode: String, error: Boolean = false) = sendBroadcast(Intent(ACTION_PROGRESS).setPackage(packageName).putExtra("progress", progress).putExtra("text", text).putExtra("finished", finished).putExtra("error", error).putExtra("taskMode", mode).putExtra("paused", false).putExtra("acceleration", accelerationMode).putExtra("fps", lastFps).putExtra("speed", lastSpeed))

    private fun update(title: String, progress: Int, text: String, finished: Boolean, taskMode: String, paused: Boolean = false, error: Boolean = false, completed: Set<Int> = loadCompleted(), currentIndex: Int = -1, currentFileProgress: Int = 0, total: Int = currentTask?.uris?.size ?: 0) {
        val safeProgress = if (finished && progress >= 100) 100 else maxOf(progressValue, progress).coerceIn(0, 100)
        progressValue = safeProgress
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(title, safeProgress, text, paused))
        sendBroadcast(Intent(ACTION_PROGRESS).setPackage(packageName)
            .putExtra("progress", safeProgress).putExtra("text", text).putExtra("finished", finished)
            .putExtra("taskMode", taskMode).putExtra("paused", paused).putExtra("error", error)
            .putExtra("completed", completed.joinToString(","))
            .putExtra("currentIndex", currentIndex).putExtra("currentFileProgress", currentFileProgress)
            .putExtra("total", total).putExtra("acceleration", accelerationMode).putExtra("fps", lastFps).putExtra("speed", lastSpeed))
    }

    private fun buildNotification(title: String, progress: Int, text: String, isPaused: Boolean): Notification {
        val pauseAction = if (isPaused) ACTION_RESUME else ACTION_PAUSE
        val pauseText = if (isPaused) "继续" else "暂停"
        val pauseIntent = PendingIntent.getService(this, 10, Intent(this, MediaProcessingService::class.java).setAction(pauseAction), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cancelIntent = PendingIntent.getService(this, 9, Intent(this, MediaProcessingService::class.java).setAction(ACTION_CANCEL), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setOngoing(!isPaused && progress < 100)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setProgress(100, progress.coerceIn(0, 100), false)
            .addAction(android.R.drawable.ic_media_pause, pauseText, pauseIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "取消", cancelIntent)
        return builder.build()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "媒体转换", NotificationManager.IMPORTANCE_LOW).apply { description = "WRZ Media 后台转换进度" })
    }

    private fun stopNow() { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE); stopSelf() }
    override fun onDestroy() { cancelSessions(); scope.cancel(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.wrz.media.START"
        const val ACTION_CANCEL = "com.wrz.media.CANCEL"
        const val ACTION_PAUSE = "com.wrz.media.PAUSE"
        const val ACTION_RESUME = "com.wrz.media.RESUME"
        const val ACTION_PROGRESS = "com.wrz.media.PROGRESS"
        const val CHANNEL_ID = "media_processing"
        const val NOTIFICATION_ID = 2026
        const val PREFS = "wrz_media_tasks"
        const val KEY_TASK = "task"
        const val KEY_COMPLETED = "completed"
        const val KEY_PARALLEL = "parallel_workers"
        const val KEY_PAUSED = "paused"
        @Volatile var progressValue: Int = 0

        fun start(context: Context, task: TaskData) { ContextCompat.startForegroundService(context, task.toIntent(context).setAction(ACTION_START)) }
        fun pause(context: Context) {
            context.startService(Intent(context, MediaProcessingService::class.java).setAction(ACTION_PAUSE))
        }
        fun resume(context: Context) {
            context.startService(Intent(context, MediaProcessingService::class.java).setAction(ACTION_RESUME))
        }
        fun cancel(context: Context) { context.startService(Intent(context, MediaProcessingService::class.java).setAction(ACTION_CANCEL)) }
        fun hasSavedTask(context: Context): Boolean = context.getSharedPreferences(PREFS, MODE_PRIVATE).contains(KEY_TASK)
        fun savedCompleted(context: Context): Set<Int> = context.getSharedPreferences(PREFS, MODE_PRIVATE).getStringSet(KEY_COMPLETED, emptySet())?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()
        fun savedTask(context: Context): TaskData? = context.getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_TASK, null)?.let { runCatching { TaskData.fromJson(JSONObject(it)) }.getOrNull() }
    }
}

data class TaskData(
    val mode: String,
    val title: String,
    val uris: List<String>,
    val names: List<String>,
    val outputTree: String,
    val outputExt: String = "mp3",
    val bitrate: Int = 192,
    val videoCodec: String = "H.264 / AVC",
    val videoExt: String = "mp4",
    val crf: Int = 23,
    val preset: String = "medium",
    val mergeName: String = "merged.mp4",
    val mergeAudioCodec: String = "aac",
    val parallel: Int = 0
) {
    fun toIntent(context: Context) = Intent(context, MediaProcessingService::class.java).apply {
        putExtra("mode", mode); putExtra("title", title); putStringArrayListExtra("uris", ArrayList(uris)); putStringArrayListExtra("names", ArrayList(names)); putExtra("outputTree", outputTree); putExtra("outputExt", outputExt); putExtra("bitrate", bitrate); putExtra("videoCodec", videoCodec); putExtra("videoExt", videoExt); putExtra("crf", crf); putExtra("preset", preset); putExtra("mergeName", mergeName); putExtra("parallel", parallel)
    }
    fun toJson() = JSONObject().apply { put("mode", mode); put("title", title); put("uris", JSONArray(uris)); put("names", JSONArray(names)); put("outputTree", outputTree); put("outputExt", outputExt); put("bitrate", bitrate); put("videoCodec", videoCodec); put("videoExt", videoExt); put("crf", crf); put("preset", preset); put("mergeName", mergeName); put("parallel", parallel) }
    companion object {
        fun fromIntent(i: Intent): TaskData? {
            val mode = i.getStringExtra("mode") ?: return null
            val title = i.getStringExtra("title") ?: "WRZ Media"
            val uris = i.getStringArrayListExtra("uris") ?: return null
            val names = i.getStringArrayListExtra("names") ?: arrayListOf()
            val out = i.getStringExtra("outputTree") ?: return null
            return TaskData(
                mode, title, uris, names, out,
                i.getStringExtra("outputExt") ?: "mp3",
                i.getIntExtra("bitrate", 192),
                i.getStringExtra("videoCodec") ?: "H.264 / AVC",
                i.getStringExtra("videoExt") ?: "mp4",
                i.getIntExtra("crf", 23),
                i.getStringExtra("preset") ?: "medium",
                i.getStringExtra("mergeName") ?: "merged.mp4",
                i.getStringExtra("mergeAudioCodec") ?: "aac",
                i.getIntExtra("parallel", 0)
            )
        }

        fun fromJson(o: JSONObject): TaskData {
            fun arr(key: String): List<String> {
                val a = o.getJSONArray(key)
                val result = ArrayList<String>(a.length())
                for (i in 0 until a.length()) result.add(a.getString(i))
                return result
            }
            return TaskData(
                o.getString("mode"),
                o.getString("title"),
                arr("uris"),
                arr("names"),
                o.getString("outputTree"),
                o.optString("outputExt", "mp3"),
                o.optInt("bitrate", 192),
                o.optString("videoCodec", "H.264 / AVC"),
                o.optString("videoExt", "mp4"),
                o.optInt("crf", 23),
                o.optString("preset", "medium"),
                o.optString("mergeName", "merged.mp4"),
                o.optString("mergeAudioCodec", "aac"),
                o.optInt("parallel", 0)
            )
        }
    }
}
