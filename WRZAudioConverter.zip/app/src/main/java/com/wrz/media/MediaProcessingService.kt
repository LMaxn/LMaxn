package com.wrz.media

import android.app.*
import android.content.*
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.Statistics
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import java.util.Locale

class MediaProcessingService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var currentSession: FFmpegSession? = null
    private var cancelled = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> { cancelled = true; currentSession?.let { FFmpegKit.cancel(it.sessionId) }; stopNow() }
            ACTION_START -> {
                cancelled = false
                val task = TaskData.fromIntent(intent)
                if (task == null) {
                    sendStatus(0, "任务参数无效，无法启动", true)
                    stopSelf()
                    return START_NOT_STICKY
                }
                try {
                    startAsForeground(task.title)
                    update(task.title, 0, "任务已启动，正在读取文件…", false)
                } catch (e: Throwable) {
                    val message = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
                    sendStatus(0, "后台任务启动失败：$message", true)
                    stopSelf()
                    return START_NOT_STICKY
                }
                scope.launch { process(task) }
            }
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground(title: String) {
        val notification = buildNotification(title, 0, "准备中")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private suspend fun process(task: TaskData) {
        try {
            when (task.mode) {
                "audio" -> processBatch(task, ::audioCommand)
                "video" -> processBatch(task, ::videoCommand)
                "merge" -> processMerge(task)
                else -> error("未知任务类型：${task.mode}")
            }
        } catch (e: CancellationException) {
            update(task.title, 0, "已取消", true)
        } catch (e: Exception) {
            val message = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
            update(task.title, 0, "失败：$message", true)
        } finally {
            stopNow()
        }
    }

    private suspend fun processBatch(task: TaskData, commandBuilder: (String, String, TaskData) -> String) {
        var success = 0
        task.uris.forEachIndexed { index, uriString ->
            if (cancelled) return
            val uri = Uri.parse(uriString)
            val name = task.names.getOrNull(index) ?: "media_$index"
            update(task.title, ((index.toDouble() / task.uris.size) * 100).toInt(), "正在处理：$name", false)
            val input = copyToCache(uri, "wrz_input_${System.currentTimeMillis()}_$index")
            val ext = if (task.mode == "audio") task.outputExt.lowercase(Locale.US) else "mp4"
            val base = name.substringBeforeLast('.', name).ifBlank { "media_$index" }
            val output = File(cacheDir, "wrz_output_${System.currentTimeMillis()}_$index.$ext")
            try {
                val command = commandBuilder(input.absolutePath, output.absolutePath, task)
                val session = executeWithProgress(command, task.title, name, index, task.uris.size, input)
                if (!cancelled && ReturnCode.isSuccess(session.returnCode)) {
                    copyToTree(output, Uri.parse(task.outputTree), uniqueName(Uri.parse(task.outputTree), "$base.$ext"))
                    success++
                    update(task.title, (((index + 1).toDouble() / task.uris.size) * 100).toInt(), "完成：$name", false)
                } else if (!cancelled) {
                    val detail = session.failStackTrace?.lineSequence()?.lastOrNull { it.isNotBlank() }
                        ?: "FFmpeg 返回码：${session.returnCode}"
                    update(task.title, ((index.toDouble() / task.uris.size) * 100).toInt(), "失败：$name · $detail", false)
                }
            } finally {
                input.delete(); output.delete()
            }
        }
        if (!cancelled) update(task.title, 100, "全部完成：$success / ${task.uris.size}", true)
    }

    private suspend fun processMerge(task: TaskData) {
        val video = copyToCache(Uri.parse(task.uris[0]), "wrz_merge_video_${System.currentTimeMillis()}")
        val audio = copyToCache(Uri.parse(task.uris[1]), "wrz_merge_audio_${System.currentTimeMillis()}")
        val output = File(cacheDir, "wrz_merge_${System.currentTimeMillis()}.mp4")
        try {
            update(task.title, 0, "正在合并", false)
            val command = "-y -i ${quote(video.absolutePath)} -i ${quote(audio.absolutePath)} -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a ${task.bitrate}k -movflags +faststart -shortest ${quote(output.absolutePath)}"
            val session = executeWithProgress(command, task.title, task.names.getOrNull(0) ?: "合并", 0, 1, video)
            if (!cancelled && ReturnCode.isSuccess(session.returnCode)) {
                copyToTree(output, Uri.parse(task.outputTree), uniqueName(Uri.parse(task.outputTree), task.mergeName.ifBlank { "merged.mp4" }))
                update(task.title, 100, "合并完成", true)
            } else if (!cancelled) {
                val detail = session.failStackTrace?.lineSequence()?.lastOrNull { it.isNotBlank() }
                    ?: "FFmpeg 返回码：${session.returnCode}"
                update(task.title, 0, "合并失败：$detail", true)
            }
        } finally { video.delete(); audio.delete(); output.delete() }
    }

    private suspend fun executeWithProgress(command: String, title: String, name: String, index: Int, total: Int, input: File): FFmpegSession = suspendCancellableCoroutine { cont ->
        currentSession = null
        val duration = mediaDurationMs(input)
        try {
            currentSession = FFmpegKit.executeAsync(command, { session ->
                currentSession = null
                if (!cont.isCompleted) cont.resume(session) {}
            }, { log ->
                if (log.message.contains("Error", ignoreCase = true)) {
                    update(title, 0, "FFmpeg：${log.message.take(180)}", false)
                }
            }, { stats: Statistics ->
                val fileProgress = if (duration > 0) ((stats.time.toDouble() / duration) * 100).coerceIn(0.0, 100.0).toInt() else 0
                val overall = (((index + fileProgress / 100.0) / total) * 100).toInt().coerceIn(0, 99)
                update(title, overall, "转换中：$name · $fileProgress%", false)
            })
        } catch (e: Exception) {
            if (!cont.isCompleted) cont.resumeWith(Result.failure(e))
        }
        cont.invokeOnCancellation { currentSession?.let { FFmpegKit.cancel(it.sessionId) } }
    }

    private fun audioCommand(input: String, output: String, task: TaskData): String {
        val i = quote(input); val o = quote(output); val b = task.bitrate
        return when (task.outputExt.lowercase(Locale.US)) {
            "mp3" -> "-y -i $i -vn -c:a libmp3lame -b:a ${b}k $o"
            "m4a" -> "-y -i $i -vn -c:a aac -b:a ${b}k -movflags +faststart $o"
            "aac" -> "-y -i $i -vn -c:a aac -b:a ${b}k $o"
            "ogg" -> "-y -i $i -vn -c:a libvorbis -b:a ${b}k $o"
            "opus" -> "-y -i $i -vn -c:a libopus -b:a ${b}k $o"
            "flac" -> "-y -i $i -vn -c:a flac $o"
            "wav" -> "-y -i $i -vn -c:a pcm_s16le $o"
            else -> error("不支持的音频输出格式")
        }
    }

    private fun videoCommand(input: String, output: String, task: TaskData): String {
        val i = quote(input); val o = quote(output)
        val video = when (task.videoCodec) {
            "H.265 / HEVC" -> "libx265"
            "复制原视频流" -> "copy"
            else -> "libx264"
        }
        val videoArgs = if (video == "copy") "-c:v copy -c:a copy" else "-c:v $video -preset ${task.preset} -crf ${task.crf} -c:a aac -b:a ${task.bitrate}k"
        return "-y -i $i -map 0:v:0? -map 0:a:0? $videoArgs -movflags +faststart $o"
    }

    private fun copyToCache(uri: Uri, name: String): File {
        val displayName = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
        val originalExt = displayName?.substringAfterLast('.', "")?.lowercase(Locale.US)
        val mimeExt = contentResolver.getType(uri)?.substringAfterLast('/')?.replace(Regex("[^A-Za-z0-9]"), "")
        val ext = when {
            !originalExt.isNullOrBlank() -> originalExt
            !mimeExt.isNullOrBlank() -> mimeExt
            else -> "bin"
        }
        val file = File(cacheDir, "$name.$ext")
        contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "无法读取输入文件" }
            file.outputStream().use { output -> input.copyTo(output) }
        }
        return file
    }

    private fun copyToTree(file: File, treeUri: Uri, name: String) {
        val tree = DocumentFile.fromTreeUri(this, treeUri) ?: error("输出目录不可用")
        val mime = when (name.substringAfterLast('.', "").lowercase()) {
            "mp4" -> "video/mp4"
            "mp3" -> "audio/mpeg"
            "wav" -> "audio/wav"
            "flac" -> "audio/flac"
            "m4a" -> "audio/mp4"
            "aac" -> "audio/aac"
            "ogg" -> "audio/ogg"
            "opus" -> "audio/opus"
            else -> "application/octet-stream"
        }
        tree.createFile(mime, name)?.let { dest -> contentResolver.openOutputStream(dest.uri).use { out -> requireNotNull(out); file.inputStream().use { it.copyTo(out) } } } ?: error("无法创建输出文件")
    }

    private fun uniqueName(treeUri: Uri, desired: String): String {
        val tree = DocumentFile.fromTreeUri(this, treeUri) ?: return desired
        if (tree.findFile(desired) == null) return desired
        val base = desired.substringBeforeLast('.', desired); val ext = desired.substringAfterLast('.', "")
        var n = 1
        while (tree.findFile("$base ($n).$ext") != null) n++
        return "$base ($n).$ext"
    }

    private fun mediaDurationMs(file: File): Long = try {
        val r = android.media.MediaMetadataRetriever(); r.setDataSource(file.absolutePath); val d = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0; r.release(); d
    } catch (_: Exception) { 0 }

    private fun quote(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun sendStatus(progress: Int, text: String, finished: Boolean) {
        sendBroadcast(
            Intent(ACTION_PROGRESS).setPackage(packageName)
                .putExtra("progress", progress)
                .putExtra("text", text)
                .putExtra("finished", finished)
        )
    }

    private fun update(title: String, progress: Int, text: String, finished: Boolean) {
        val notification = buildNotification(title, progress, text)
        val nm = getSystemService(NotificationManager::class.java); nm.notify(NOTIFICATION_ID, notification)
        sendBroadcast(Intent(ACTION_PROGRESS).setPackage(packageName).putExtra("progress", progress).putExtra("text", text).putExtra("finished", finished))
    }

    private fun buildNotification(title: String, progress: Int, text: String): Notification {
        val cancelIntent = PendingIntent.getService(this, 9, Intent(this, MediaProcessingService::class.java).setAction(ACTION_CANCEL), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(progress < 100)
            .setOnlyAlertOnce(true)
            .setProgress(100, progress.coerceIn(0, 100), false)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "取消", cancelIntent)
        addXiaomiIsland(builder, title, text, progress)
        return builder.build()
    }

    private fun addXiaomiIsland(builder: NotificationCompat.Builder, title: String, text: String, progress: Int) {
        if (Build.MANUFACTURER.equals("Xiaomi", true) || Build.MANUFACTURER.equals("XIAOMI", true)) {
            try {
                val json = JSONObject().apply {
                    put("islandProperty", 2)
                    put("islandOrder", true)
                    put("param_island", JSONObject().apply {
                        put("smallIslandArea", JSONObject().apply { put("title", title); put("content", "$progress%") })
                        put("bigIslandArea", JSONObject().apply { put("title", title); put("content", text) })
                    })
                }
                builder.extras.putString("miui.focus.param", json.toString())
            } catch (_: Exception) { }
        }
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "媒体转换", NotificationManager.IMPORTANCE_LOW))
    }

    private fun stopNow() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.wrz.media.START"
        const val ACTION_CANCEL = "com.wrz.media.CANCEL"
        const val ACTION_PROGRESS = "com.wrz.media.PROGRESS"
        const val CHANNEL_ID = "media_processing"
        const val NOTIFICATION_ID = 2026

        fun start(context: Context, task: TaskData) {
            val intent = task.toIntent(context).setAction(ACTION_START)
            ContextCompat.startForegroundService(context, intent)
        }
        fun cancel(context: Context) { context.startService(Intent(context, MediaProcessingService::class.java).setAction(ACTION_CANCEL)) }
    }
}

data class TaskData(
    val mode: String,
    val title: String,
    val uris: List<String>,
    val names: List<String>,
    val outputTree: String,
    val outputExt: String = "mp3",
    val bitrate: Int = 192,
    val videoCodec: String = "H.264 / AVC",
    val crf: Int = 23,
    val preset: String = "medium",
    val mergeName: String = "merged.mp4"
) {
    fun toIntent(context: Context) = Intent(context, MediaProcessingService::class.java).apply {
        putExtra("mode", mode); putExtra("title", title); putStringArrayListExtra("uris", ArrayList(uris)); putStringArrayListExtra("names", ArrayList(names)); putExtra("outputTree", outputTree); putExtra("outputExt", outputExt); putExtra("bitrate", bitrate); putExtra("videoCodec", videoCodec); putExtra("crf", crf); putExtra("preset", preset); putExtra("mergeName", mergeName)
    }
    companion object {
        fun fromIntent(i: Intent): TaskData? {
            val mode = i.getStringExtra("mode") ?: return null
            val title = i.getStringExtra("title") ?: "WRZ Media"
            val uris = i.getStringArrayListExtra("uris") ?: return null
            val names = i.getStringArrayListExtra("names") ?: arrayListOf()
            val out = i.getStringExtra("outputTree") ?: return null
            return TaskData(mode, title, uris, names, out, i.getStringExtra("outputExt") ?: "mp3", i.getIntExtra("bitrate", 192), i.getStringExtra("videoCodec") ?: "H.264 / AVC", i.getIntExtra("crf", 23), i.getStringExtra("preset") ?: "medium", i.getStringExtra("mergeName") ?: "merged.mp4")
        }
    }
}
