package com.wrz.media

import android.app.*
import android.content.*
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.Statistics
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

class MediaProcessingService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val sessions = ConcurrentHashMap<Long, FFmpegSession>()
    private val outputLock = Any()
    @Volatile private var cancelled = false
    @Volatile private var paused = false
    private var currentTask: TaskData? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                cancelled = true
                paused = false
                cancelSessions()
                clearSavedTask()
                update("WRZ Media", 0, "任务已取消", true, taskMode = currentTask?.mode ?: "")
                stopNow()
            }
            ACTION_PAUSE -> {
                if (currentTask != null) {
                    paused = true
                    cancelled = false
                    saveTask(currentTask!!)
                    cancelSessions()
                    update(currentTask!!.title, progressValue, "已暂停（断点已保存）", true, taskMode = currentTask!!.mode, paused = true)
                    stopNow()
                }
            }
            ACTION_RESUME -> {
                val task = loadSavedTask() ?: TaskData.fromIntent(intent)
                if (task != null) startTask(task, resume = true)
                else sendStatus(0, "没有可恢复的任务", true, "")
            }
            ACTION_START -> {
                val task = TaskData.fromIntent(intent)
                if (task == null) {
                    sendStatus(0, "任务参数无效，无法启动", true, "")
                    stopSelf()
                } else startTask(task, resume = false)
            }
        }
        return START_NOT_STICKY
    }

    private fun startTask(task: TaskData, resume: Boolean) {
        cancelled = false
        paused = false
        currentTask = task
        if (!resume) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_COMPLETED).apply()
            saveTask(task)
        }
        try {
            startAsForeground(task.title)
            update(task.title, if (resume) progressValue else 0, if (resume) "正在恢复任务…" else "任务已启动，正在读取文件…", false, task.mode)
        } catch (e: Throwable) {
            val message = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
            sendStatus(0, "后台任务启动失败：$message", true, task.mode)
            return
        }
        scope.launch {
            try {
                when (task.mode) {
                    "audio" -> processBatch(task, ::audioCommand)
                    "video" -> processBatch(task, ::videoCommand)
                    "merge" -> processMerge(task)
                    else -> error("未知任务类型：${task.mode}")
                }
            } catch (e: CancellationException) {
                if (!paused && !cancelled) update(task.title, 0, "任务已停止", true, task.mode)
            } catch (e: Exception) {
                val message = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
                update(task.title, progressValue, "失败：$message", true, task.mode)
            } finally {
                if (!paused && !cancelled) {
                    clearSavedTask()
                    stopNow()
                }
            }
        }
    }

    private fun startAsForeground(title: String) {
        val notification = buildNotification(title, 0, "准备中", false)
        if (Build.VERSION.SDK_INT >= 35) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING)
        } else if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else startForeground(NOTIFICATION_ID, notification)
    }

    private suspend fun processBatch(task: TaskData, commandBuilder: (String, String, TaskData) -> String) = coroutineScope {
        val completed: MutableSet<Int> = java.util.Collections.synchronizedSet(loadCompleted().toMutableSet())
        val total = task.uris.size
        if (total == 0) error("没有可转换的文件")
        val workers = parallelWorkers()
        update(task.title, overallProgress(completed, total), "队列 ${total - completed.size} 个 · 并行 ${workers} 路", false, task.mode)

        val queue = task.uris.indices.filter { it !in completed }
        val cursor = java.util.concurrent.atomic.AtomicInteger(0)
        val jobs = List(minOf(workers, queue.size)) {
            launch(Dispatchers.IO) {
                while (true) {
                    if (cancelled || paused) return@launch
                    val pos = cursor.getAndIncrement()
                    if (pos >= queue.size) return@launch
                    val index = queue[pos]
                    val uri = Uri.parse(task.uris[index])
                    val name = task.names.getOrNull(index) ?: "media_$index"
                    var input: File? = null
                    var output: File? = null
                    try {
                        update(task.title, overallProgress(completed, total), "处理中：$name", false, task.mode)
                        input = copyToCache(uri, "wrz_input_${System.currentTimeMillis()}_$index")
                        val ext = if (task.mode == "audio") task.outputExt.lowercase(Locale.US) else "mp4"
                        val base = name.substringBeforeLast('.', name).ifBlank { "media_$index" }
                        output = File(cacheDir, "wrz_output_${System.currentTimeMillis()}_$index.$ext")
                        val command = commandBuilder(input.absolutePath, output.absolutePath, task)
                        val session = executeWithProgress(command, task.title, name, index, total, input)
                        if (paused || cancelled) return@launch
                        if (ReturnCode.isSuccess(session.returnCode)) {
                            synchronized(outputLock) {
                                copyToTree(output, Uri.parse(task.outputTree), uniqueName(Uri.parse(task.outputTree), "$base.$ext"))
                                completed += index
                                saveCompleted(completed)
                            }
                            update(task.title, overallProgress(completed, total), "完成：$name · ${completed.size}/$total", false, task.mode)
                        } else {
                            val detail = session.failStackTrace?.lineSequence()?.lastOrNull { it.isNotBlank() } ?: "FFmpeg 返回码：${session.returnCode}"
                            update(task.title, overallProgress(completed, total), "失败：$name · ${detail.take(100)}", false, task.mode)
                        }
                    } catch (e: CancellationException) {
                        return@launch
                    } catch (e: Exception) {
                        update(task.title, overallProgress(completed, total), "失败：$name · ${e.message ?: e.javaClass.simpleName}", false, task.mode)
                    } finally {
                        input?.delete(); output?.delete()
                    }
                }
            }
        }
        jobs.joinAll()
        if (!paused && !cancelled) {
            if (completed.size == total) {
                update(task.title, 100, "全部完成：$total / $total", true, task.mode)
            } else {
                saveTask(task)
                update(task.title, overallProgress(completed, total), "已暂停，${completed.size}/$total 个文件已完成", true, task.mode, paused = true)
            }
        }
    }

    private suspend fun processMerge(task: TaskData) {
        val video = copyToCache(Uri.parse(task.uris[0]), "wrz_merge_video_${System.currentTimeMillis()}")
        val audio = copyToCache(Uri.parse(task.uris[1]), "wrz_merge_audio_${System.currentTimeMillis()}")
        val output = File(cacheDir, "wrz_merge_${System.currentTimeMillis()}.mp4")
        try {
            update(task.title, 0, "正在合并", false, task.mode)
            val command = "-y -i ${quote(video.absolutePath)} -i ${quote(audio.absolutePath)} -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a ${task.bitrate}k -movflags +faststart -shortest ${quote(output.absolutePath)}"
            val session = executeWithProgress(command, task.title, task.names.getOrNull(0) ?: "合并", 0, 1, video)
            if (!paused && !cancelled && ReturnCode.isSuccess(session.returnCode)) {
                copyToTree(output, Uri.parse(task.outputTree), uniqueName(Uri.parse(task.outputTree), task.mergeName.ifBlank { "merged.mp4" }))
                update(task.title, 100, "合并完成", true, task.mode)
            } else if (!paused && !cancelled) {
                val detail = session.failStackTrace?.lineSequence()?.lastOrNull { it.isNotBlank() } ?: "FFmpeg 返回码：${session.returnCode}"
                update(task.title, 0, "合并失败：$detail", true, task.mode)
            } else if (paused) {
                saveTask(task)
            }
        } finally { video.delete(); audio.delete(); output.delete() }
    }

    private suspend fun executeWithProgress(command: String, title: String, name: String, index: Int, total: Int, input: File): FFmpegSession = suspendCancellableCoroutine { cont ->
        val duration = mediaDurationMs(input)
        try {
            val session = FFmpegKit.executeAsync(command, { result ->
                sessions.remove(result.sessionId)
                if (!cont.isCompleted) cont.resume(result)
            }, { log ->
                if (log.message.contains("Error", ignoreCase = true)) update(title, progressValue, "FFmpeg：${log.message.take(160)}", false, currentTask?.mode ?: "")
            }, { stats: Statistics ->
                val fileProgress = if (duration > 0) ((stats.time.toDouble() / duration) * 100).coerceIn(0.0, 100.0).toInt() else 0
                val overall = (((index + fileProgress / 100.0) / total) * 100).toInt().coerceIn(0, 99)
                progressValue = overall
                update(title, overall, "处理中：$name · $fileProgress%", false, currentTask?.mode ?: "")
            })
            sessions[session.sessionId] = session
        } catch (e: Exception) {
            if (!cont.isCompleted) cont.resumeWithException(e)
        }
        cont.invokeOnCancellation { sessions.values.forEach { FFmpegKit.cancel(it.sessionId) } }
    }

    private fun audioCommand(input: String, output: String, task: TaskData): String {
        val i = quote(input); val o = quote(output); val b = task.bitrate
        return when (task.outputExt.lowercase(Locale.US)) {
            "mp3" -> "-y -threads 0 -i $i -vn -c:a libmp3lame -b:a ${b}k $o"
            "m4a" -> "-y -threads 0 -i $i -vn -c:a aac -b:a ${b}k -movflags +faststart $o"
            "aac" -> "-y -threads 0 -i $i -vn -c:a aac -b:a ${b}k $o"
            "ogg" -> "-y -threads 0 -i $i -vn -c:a libvorbis -b:a ${b}k $o"
            "opus" -> "-y -threads 0 -i $i -vn -c:a libopus -b:a ${b}k $o"
            "flac" -> "-y -threads 0 -i $i -vn -c:a flac $o"
            "wav" -> "-y -threads 0 -i $i -vn -c:a pcm_s16le $o"
            else -> error("不支持的音频输出格式")
        }
    }

    private fun videoCommand(input: String, output: String, task: TaskData): String {
        val i = quote(input); val o = quote(output)
        val video = when (task.videoCodec) { "H.265 / HEVC" -> "libx265"; "复制原视频流" -> "copy"; else -> "libx264" }
        val videoArgs = if (video == "copy") "-c:v copy -c:a copy" else "-threads 0 -c:v $video -preset ${task.preset} -crf ${task.crf} -c:a aac -b:a ${task.bitrate}k"
        return "-y -i $i -map 0:v:0? -map 0:a:0? $videoArgs -movflags +faststart $o"
    }

    private fun copyToCache(uri: Uri, name: String): File {
        val displayName = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        val originalExt = displayName?.substringAfterLast('.', "")?.lowercase(Locale.US)
        val mimeExt = contentResolver.getType(uri)?.substringAfterLast('/')?.replace(Regex("[^A-Za-z0-9]"), "")
        val ext = when { !originalExt.isNullOrBlank() -> originalExt; !mimeExt.isNullOrBlank() -> mimeExt; else -> "bin" }
        val file = File(cacheDir, "$name.$ext")
        contentResolver.openInputStream(uri).use { input -> requireNotNull(input) { "无法读取输入文件" }; file.outputStream().use { output -> input.copyTo(output) } }
        return file
    }

    private fun copyToTree(file: File, treeUri: Uri, name: String) {
        val tree = DocumentFile.fromTreeUri(this, treeUri) ?: error("输出目录不可用")
        val mime = when (name.substringAfterLast('.', "").lowercase()) { "mp4" -> "video/mp4"; "mp3" -> "audio/mpeg"; "wav" -> "audio/wav"; "flac" -> "audio/flac"; "m4a" -> "audio/mp4"; "aac" -> "audio/aac"; "ogg" -> "audio/ogg"; "opus" -> "audio/opus"; else -> "application/octet-stream" }
        tree.createFile(mime, name)?.let { dest -> contentResolver.openOutputStream(dest.uri).use { out -> requireNotNull(out); file.inputStream().use { it.copyTo(out) } } } ?: error("无法创建输出文件")
    }

    private fun uniqueName(treeUri: Uri, desired: String): String {
        val tree = DocumentFile.fromTreeUri(this, treeUri) ?: return desired
        if (tree.findFile(desired) == null) return desired
        val base = desired.substringBeforeLast('.', desired); val ext = desired.substringAfterLast('.', "")
        var n = 1
        while (tree.findFile("$base ($n).$ext") != null) n++
        return "$base ($n).$ext"
    }

    private fun mediaDurationMs(file: File): Long = try { val r = android.media.MediaMetadataRetriever(); r.setDataSource(file.absolutePath); val d = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0; r.release(); d } catch (_: Exception) { 0 }
    private fun quote(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun parallelWorkers(): Int {
        val pref = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(KEY_PARALLEL, 0)
        if (pref > 0) return pref.coerceIn(1, 4)
        val cores = Runtime.getRuntime().availableProcessors()
        return when { cores >= 8 -> 4; cores >= 4 -> 2; else -> 1 }
    }

    private fun cancelSessions() { sessions.values.forEach { try { FFmpegKit.cancel(it.sessionId) } catch (_: Exception) {} }; sessions.clear() }

    private fun overallProgress(done: Set<Int>, total: Int) = if (total == 0) 0 else (done.size * 100 / total).coerceIn(0, 99)

    private fun saveTask(task: TaskData) { getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_TASK, task.toJson().toString()).apply() }
    private fun loadSavedTask(): TaskData? = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_TASK, null)?.let { runCatching { TaskData.fromJson(JSONObject(it)) }.getOrNull() }
    private fun clearSavedTask() { getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_TASK).remove(KEY_COMPLETED).apply() }
    private fun saveCompleted(completed: Set<Int>) { getSharedPreferences(PREFS, MODE_PRIVATE).edit().putStringSet(KEY_COMPLETED, completed.map { it.toString() }.toSet()).apply() }
    private fun loadCompleted(): Set<Int> = getSharedPreferences(PREFS, MODE_PRIVATE).getStringSet(KEY_COMPLETED, emptySet())?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()

    private fun sendStatus(progress: Int, text: String, finished: Boolean, mode: String) = sendBroadcast(Intent(ACTION_PROGRESS).setPackage(packageName).putExtra("progress", progress).putExtra("text", text).putExtra("finished", finished).putExtra("taskMode", mode).putExtra("paused", false))

    private fun update(title: String, progress: Int, text: String, finished: Boolean, taskMode: String, paused: Boolean = false) {
        progressValue = progress
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(title, progress, text, paused))
        sendBroadcast(Intent(ACTION_PROGRESS).setPackage(packageName).putExtra("progress", progress).putExtra("text", text).putExtra("finished", finished).putExtra("taskMode", taskMode).putExtra("paused", paused))
    }

    private fun buildNotification(title: String, progress: Int, text: String, isPaused: Boolean): Notification {
        val pauseAction = if (isPaused) ACTION_RESUME else ACTION_PAUSE
        val pauseText = if (isPaused) "继续" else "暂停"
        val pauseIntent = PendingIntent.getService(this, 10, Intent(this, MediaProcessingService::class.java).setAction(pauseAction), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cancelIntent = PendingIntent.getService(this, 9, Intent(this, MediaProcessingService::class.java).setAction(ACTION_CANCEL), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setOngoing(!isPaused && progress < 100)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setProgress(100, progress.coerceIn(0, 100), false)
            .addAction(android.R.drawable.ic_media_pause, pauseText, pauseIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "取消", cancelIntent)
        addXiaomiIsland(builder, title, text, progress, isPaused)
        return builder.build()
    }

    private fun addXiaomiIsland(builder: NotificationCompat.Builder, title: String, text: String, progress: Int, isPaused: Boolean) {
        if (!Build.MANUFACTURER.equals("Xiaomi", true)) return
        try {
            val root = JSONObject().apply {
                put("param_v2", JSONObject().apply {
                    put("protocol", 1)
                    put("business", "wrz_media")
                    put("enableFloat", true)
                    put("updatable", true)
                    put("ticker", "$title · ${progress}%")
                    put("baseInfo", JSONObject().apply { put("title", title); put("content", text) })
                    put("param_island", JSONObject().apply {
                        put("islandProperty", 2)
                        put("islandOrder", true)
                        put("bigIslandArea", JSONObject().apply { put("title", title); put("content", text) })
                        put("smallIslandArea", JSONObject().apply { put("title", title); put("content", if (isPaused) "已暂停" else "$progress%") })
                    })
                })
            }
            builder.extras.putString("miui.focus.param", root.toString())
        } catch (_: Exception) {}
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "媒体转换", NotificationManager.IMPORTANCE_LOW).apply { description = "WRZ Media 后台转换进度" })
    }

    private fun stopNow() { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE); stopSelf() }
    override fun onDestroy() { cancelSessions(); scope.cancel(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.wrz.media.START"
        const val ACTION_CANCEL = "com.wrz.media.CANCEL"
        const val ACTION_PAUSE = "com.wrz.media.PAUSE"
        const val ACTION_RESUME = "com.wrz.media.RESUME"
        const val ACTION_PROGRESS = "com.wrz.media.PROGRESS"
        const val CHANNEL_ID = "media_processing"
        const val NOTIFICATION_ID = 2026
        const val PREFS = "wrz_media_tasks"
        const val KEY_TASK = "task"
        const val KEY_COMPLETED = "completed"
        const val KEY_PARALLEL = "parallel_workers"
        @Volatile var progressValue: Int = 0

        fun start(context: Context, task: TaskData) { ContextCompat.startForegroundService(context, task.toIntent(context).setAction(ACTION_START)) }
        fun pause(context: Context) { context.startService(Intent(context, MediaProcessingService::class.java).setAction(ACTION_PAUSE)) }
        fun resume(context: Context) { ContextCompat.startForegroundService(context, Intent(context, MediaProcessingService::class.java).setAction(ACTION_RESUME)) }
        fun cancel(context: Context) { context.startService(Intent(context, MediaProcessingService::class.java).setAction(ACTION_CANCEL)) }
        fun hasSavedTask(context: Context): Boolean = context.getSharedPreferences(PREFS, MODE_PRIVATE).contains(KEY_TASK)
        fun savedTask(context: Context): TaskData? = context.getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_TASK, null)?.let { runCatching { TaskData.fromJson(JSONObject(it)) }.getOrNull() }
    }
}

data class TaskData(
    val mode: String,
    val title: String,
    val uris: List<String>,
    val names: List<String>,
    val outputTree: String,
    val outputExt: String = "mp3",
    val bitrate: Int = 192,
    val videoCodec: String = "H.264 / AVC",
    val crf: Int = 23,
    val preset: String = "medium",
    val mergeName: String = "merged.mp4"
) {
    fun toIntent(context: Context) = Intent(context, MediaProcessingService::class.java).apply {
        putExtra("mode", mode); putExtra("title", title); putStringArrayListExtra("uris", ArrayList(uris)); putStringArrayListExtra("names", ArrayList(names)); putExtra("outputTree", outputTree); putExtra("outputExt", outputExt); putExtra("bitrate", bitrate); putExtra("videoCodec", videoCodec); putExtra("crf", crf); putExtra("preset", preset); putExtra("mergeName", mergeName)
    }
    fun toJson() = JSONObject().apply { put("mode", mode); put("title", title); put("uris", JSONArray(uris)); put("names", JSONArray(names)); put("outputTree", outputTree); put("outputExt", outputExt); put("bitrate", bitrate); put("videoCodec", videoCodec); put("crf", crf); put("preset", preset); put("mergeName", mergeName) }
    companion object {
        fun fromIntent(i: Intent): TaskData? { val mode = i.getStringExtra("mode") ?: return null; val title = i.getStringExtra("title") ?: "WRZ Media"; val uris = i.getStringArrayListExtra("uris") ?: return null; val names = i.getStringArrayListExtra("names") ?: arrayListOf(); val out = i.getStringExtra("outputTree") ?: return null; return TaskData(mode, title, uris, names, out, i.getStringExtra("outputExt") ?: "mp3", i.getIntExtra("bitrate", 192), i.getStringExtra("videoCodec") ?: "H.264 / AVC", i.getIntExtra("crf", 23), i.getStringExtra("preset") ?: "medium", i.getStringExtra("mergeName") ?: "merged.mp4") }
        fun fromJson(o: JSONObject): TaskData { fun arr(key: String) = buildList { val a = o.getJSONArray(key); for (i in 0 until a.length()) add(a.getString(i)) }; return TaskData(o.getString("mode"), o.getString("title"), arr("uris"), arr("names"), o.getString("outputTree"), o.optString("outputExt", "mp3"), o.optInt("bitrate", 192), o.optString("videoCodec", "H.264 / AVC"), o.optInt("crf", 23), o.optString("preset", "medium"), o.optString("mergeName", "merged.mp4")) }
    }
}
