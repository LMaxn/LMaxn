package com.wrz.media

import android.Manifest
import android.content.*
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private val AUDIO_EXT = setOf("mp3","wav","flac","m4a","aac","ogg","opus","wma","aiff","aif","amr","mka","ape")
private val VIDEO_EXT = setOf("mp4","mkv","mov","webm","avi","flv","ts","m4v","3gp","wmv")

data class MediaFile(val uri: Uri, val name: String, val isVideo: Boolean)

data class MediaInfo(
    val size: String,
    val duration: String,
    val mime: String,
    val videoCodec: String,
    val width: String,
    val height: String,
    val fps: String,
    val audioCodec: String,
    val audioRate: String
)

class MainActivity : ComponentActivity() {
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            progressState.value = intent?.getIntExtra("progress", 0) ?: 0
            progressText.value = intent?.getStringExtra("text") ?: ""
            runningState.value = !(intent?.getBooleanExtra("finished", false) ?: false)
        }
    }
    private val progressState = mutableIntStateOf(0)
    private val progressText = mutableStateOf("")
    private val runningState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3001)
        ContextCompat.registerReceiver(this, receiver, IntentFilter(MediaProcessingService.ACTION_PROGRESS), ContextCompat.RECEIVER_NOT_EXPORTED)
        setContent {
            WRZMediaApp(
                progressState, progressText, runningState,
                onStartTask = { task -> startTask(task) }
            )
        }
    }

    private fun startTask(task: TaskData) {
        progressState.intValue = 0
        progressText.value = "正在启动后台任务…"
        runningState.value = true
        try {
            MediaProcessingService.start(this, task)
        } catch (e: Exception) {
            runningState.value = false
            progressText.value = "启动失败：${e.message ?: e.javaClass.simpleName}"
            android.widget.Toast.makeText(this, progressText.value, android.widget.Toast.LENGTH_LONG).show()
            return
        }
        // 如果 Service 在 6 秒内没有回报任何状态，明确告诉用户，而不是“什么都没有”。
        Handler(Looper.getMainLooper()).postDelayed({
            if (runningState.value && progressText.value == "正在启动后台任务…") {
                progressText.value = "后台任务未返回状态，请检查通知权限和系统后台限制"
                android.widget.Toast.makeText(this, progressText.value, android.widget.Toast.LENGTH_LONG).show()
            }
        }, 6000L)
    }

    override fun onDestroy() { unregisterReceiver(receiver); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WRZMediaApp(progress: State<Int>, progressText: State<String>, running: State<Boolean>, onStartTask: (TaskData) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var convertMode by remember { mutableStateOf("音频") }

    fun openConvert(mode: String) {
        convertMode = mode
        tab = 1
    }

    MaterialTheme(colorScheme = dynamicColorScheme()) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("WRZ Media") }, actions = { if (running.value) Text("${progress.value}%", modifier = Modifier.padding(end = 16.dp)) }) },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("首页") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Transform, null) }, label = { Text("转换") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Merge, null) }, label = { Text("合并") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("设置") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomePage(progress, progressText, running, Modifier.padding(padding), ::openConvert, { tab = 2 })
                1 -> ConvertPage(progress, progressText, running, convertMode, { convertMode = it }, Modifier.padding(padding), onStartTask)
                2 -> MergePage(progress, progressText, running, Modifier.padding(padding), onStartTask)
                else -> SettingsPage(Modifier.padding(padding))
            }
        }
    }
}

@Composable
private fun HomePage(
    progress: State<Int>,
    text: State<String>,
    running: State<Boolean>,
    modifier: Modifier,
    onConvert: (String) -> Unit,
    onMerge: () -> Unit
) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("本地媒体工具", style = MaterialTheme.typography.headlineSmall)
                Text("FFmpeg 本地处理 · 无广告 · 无会员 · 不上传文件", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (running.value || text.value.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    if (running.value) LinearProgressIndicator({ progress.value / 100f }, Modifier.fillMaxWidth())
                    Text(text.value.ifBlank { "正在处理" }, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        FeatureCard("🎵", "音频转换", "批量、文件夹、MP3 / AAC / FLAC / OPUS / WAV", "打开", { onConvert("音频") })
        FeatureCard("🎬", "视频转换", "H.264 / H.265 / 原编码复制 · 原参数可见", "打开", { onConvert("视频") })
        FeatureCard("🎞️", "音视频合并", "替换音轨，视频流默认直接复制", "打开", onMerge)
        Text("设计原则：参数透明、能不重编码就不重编码、后台任务可持续运行。", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun FeatureCard(icon: String, title: String, desc: String, tag: String, onClick: () -> Unit) {
    Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, style = MaterialTheme.typography.headlineMedium); Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.titleLarge); Text(desc, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            AssistChip(onClick = onClick, label = { Text(tag) })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConvertPage(progress: State<Int>, progressText: State<String>, running: State<Boolean>, mode: String, onModeChange: (String) -> Unit, modifier: Modifier, onStartTask: (TaskData) -> Unit) {
    val context = LocalContext.current
    var files by remember { mutableStateOf(listOf<MediaFile>()) }
    var outputTree by remember { mutableStateOf<Uri?>(null) }
    var audioExt by remember { mutableStateOf("mp3") }
    var bitrate by remember { mutableIntStateOf(192) }
    var codec by remember { mutableStateOf("H.264 / AVC") }
    var crf by remember { mutableIntStateOf(23) }
    var preset by remember { mutableStateOf("medium") }
    var selectedVideo by remember { mutableStateOf<MediaFile?>(null) }

    val scope = rememberCoroutineScope()
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        files = (files + uris.mapNotNull { makeMediaFile(context, it, mode == "视频") }).distinctBy { it.uri.toString() }
        if (mode == "视频") selectedVideo = files.firstOrNull { it.isVideo }
    }
    val inputFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            persist(context, uri)
            scope.launch(Dispatchers.IO) {
                val found = scanFolder(context, uri, mode == "视频")
                withContext(Dispatchers.Main) {
                    files = (files + found).distinctBy { it.uri.toString() }
                    if (mode == "视频") selectedVideo = files.firstOrNull { it.isVideo }
                }
            }
        }
    }
    val outputFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) { persist(context, uri); outputTree = uri }
    }
    val info by produceState<MediaInfo?>(null, selectedVideo?.uri) {
        value = selectedVideo?.let { withContext(Dispatchers.IO) { readInfo(context, it.uri) } }
    }

    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            listOf("音频", "视频").forEachIndexed { i, s -> SegmentedButton(mode == s, { onModeChange(s); files = emptyList(); selectedVideo = null }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(s) } }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { filePicker.launch(arrayOf(if (mode == "视频") "video/*" else "audio/*")) }) { Icon(Icons.Default.AttachFile, null); Spacer(Modifier.width(6.dp)); Text("选择文件") }
            OutlinedButton(onClick = { inputFolderPicker.launch(null) }) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(6.dp)); Text("添加文件夹") }
        }
        OutlinedButton(onClick = { outputFolderPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Output, null); Spacer(Modifier.width(6.dp)); Text("输出目录：${outputTree?.let { "已选择" } ?: "请选择输出目录"}")
        }
        if (mode == "视频" && selectedVideo != null) {
            VideoPreview(selectedVideo!!.uri)
            info?.let { InfoCard(it) }
        }
        if (mode == "音频") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Dropdown(audioExt, listOf("mp3","m4a","aac","flac","wav","ogg","opus")) { audioExt = it }
                if (audioExt !in setOf("flac","wav")) Dropdown("${bitrate} kbps", listOf("96 kbps","128 kbps","160 kbps","192 kbps","224 kbps","256 kbps","320 kbps")) { bitrate = it.substringBefore(' ').toInt() }
            }
        } else {
            Dropdown(codec, listOf("H.264 / AVC","H.265 / HEVC","复制原视频流")) { codec = it }
            if (codec != "复制原视频流") {
                Text("CRF：$crf（数值越小质量越高、体积越大）")
                Slider(value = crf.toFloat(), onValueChange = { crf = it.toInt() }, valueRange = 16f..30f, steps = 13)
                Dropdown("Preset：$preset", listOf("ultrafast","fast","medium","slow","veryslow")) { preset = it.substringAfter(": ") }
                Dropdown("AAC ${bitrate} kbps", listOf("96 kbps","128 kbps","160 kbps","192 kbps","256 kbps")) { bitrate = it.substringBefore(' ').toInt() }
            }
            Text("实际参数会显示在这里：-c:v ${if (codec == "H.264 / AVC") "libx264" else if (codec == "H.265 / HEVC") "libx265" else "copy"} ${if (codec == "复制原视频流") "-c:a copy" else "-crf $crf -preset $preset -c:a aac -b:a ${bitrate}k"}", style = MaterialTheme.typography.bodySmall)
        }
        Text("已选 ${files.size} 个文件", style = MaterialTheme.typography.titleMedium)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) { items(files) { Text("• ${it.name}", maxLines = 1) } }
        if (running.value || progressText.value.isNotBlank()) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(progressText.value.ifBlank { "准备中…" })
                    if (running.value) LinearProgressIndicator({ progress.value / 100f }, Modifier.fillMaxWidth())
                }
            }
        }
        Button(
            enabled = files.isNotEmpty() && outputTree != null && !running.value,
            onClick = {
                val task = if (mode == "音频") {
                    TaskData("audio", "WRZ Media · 音频转换", files.map { it.uri.toString() }, files.map { it.name }, outputTree.toString(), audioExt, bitrate)
                } else {
                    TaskData("video", "WRZ Media · 视频转换", files.map { it.uri.toString() }, files.map { it.name }, outputTree.toString(), bitrate = bitrate, videoCodec = codec, crf = crf, preset = preset)
                }
                onStartTask(task)
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (running.value) "转换中… ${progress.value}%" else "开始转换") }
    }
}

@Composable
private fun MergePage(progress: State<Int>, progressText: State<String>, running: State<Boolean>, modifier: Modifier, onStartTask: (TaskData) -> Unit) {
    val context = LocalContext.current
    var video by remember { mutableStateOf<MediaFile?>(null) }
    var audio by remember { mutableStateOf<MediaFile?>(null) }
    var output by remember { mutableStateOf<Uri?>(null) }
    var bitrate by remember { mutableIntStateOf(192) }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let { video = makeMediaFile(context, it, true) } }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let { audio = makeMediaFile(context, it, false) } }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let { persist(context, it); output = it } }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("音视频合并", style = MaterialTheme.typography.headlineSmall)
        OutlinedButton(onClick = { videoPicker.launch(arrayOf("video/*")) }, Modifier.fillMaxWidth()) { Text("视频：${video?.name ?: "选择视频"}") }
        OutlinedButton(onClick = { audioPicker.launch(arrayOf("audio/*")) }, Modifier.fillMaxWidth()) { Text("音频：${audio?.name ?: "选择音频"}") }
        OutlinedButton(onClick = { folderPicker.launch(null) }, Modifier.fillMaxWidth()) { Text("输出目录：${if (output == null) "选择" else "已选择"}") }
        Dropdown("AAC ${bitrate} kbps", listOf("96 kbps","128 kbps","160 kbps","192 kbps","256 kbps")) { bitrate = it.substringBefore(' ').toInt() }
        Text("视频流默认 copy，不重新压缩；音频重新编码为 AAC。")
        if (running.value || progressText.value.isNotBlank()) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(progressText.value.ifBlank { "准备中…" })
                    if (running.value) LinearProgressIndicator({ progress.value / 100f }, Modifier.fillMaxWidth())
                }
            }
        }
        Button(enabled = video != null && audio != null && output != null && !running.value, onClick = {
            val task = TaskData(
                "merge", "WRZ Media · 音视频合并",
                listOf(video!!.uri.toString(), audio!!.uri.toString()),
                listOf(video!!.name, audio!!.name),
                output.toString(),
                bitrate = bitrate,
                mergeName = video!!.name.substringBeforeLast('.') + "_merged.mp4"
            )
            onStartTask(task)
        }, modifier = Modifier.fillMaxWidth()) { Text(if (running.value) "合并中… ${progress.value}%" else "开始合并") }
    }
}

@Composable
private fun SettingsPage(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("设置", style = MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text("WRZ Media 2.0", style = MaterialTheme.typography.titleLarge); Text("本地 FFmpeg · Android 原生界面", color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        Text("后台转码使用 Android mediaProcessing 前台服务；转换期间会显示持续通知。", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("小米 HyperOS 3：已加入超级岛通知扩展参数的兼容钩子；不支持的设备仍使用标准 Android 通知。", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun VideoPreview(uri: Uri) {
    val context = LocalContext.current
    val player = remember(uri) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(uri)); prepare() } }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } }, Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(18.dp)))
}

@Composable
private fun InfoCard(info: MediaInfo) {
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("原始媒体参数", style = MaterialTheme.typography.titleMedium)
        Text("文件：${info.size} · 时长：${info.duration} · MIME：${info.mime}")
        Text("视频：${info.videoCodec} · ${info.width}×${info.height} · ${info.fps} FPS")
        Text("音频：${info.audioCodec} · ${info.audioRate}")
    } }
}

@Composable
private fun Dropdown(value: String, options: List<String>, onPick: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }) { Text(value); Icon(Icons.Default.ArrowDropDown, null) }
        DropdownMenu(expanded, { expanded = false }) { options.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { onPick(it); expanded = false }) } }
    }
}

private fun scanFolder(context: Context, treeUri: Uri, video: Boolean): List<MediaFile> {
    val root = DocumentFile.fromTreeUri(context, treeUri) ?: return emptyList()
    val result = mutableListOf<MediaFile>()
    fun walk(dir: DocumentFile) {
        dir.listFiles().forEach { file ->
            if (file.isDirectory) walk(file)
            else if (file.isFile) makeMediaFile(context, file.uri, video)?.let { result += it }
        }
    }
    walk(root)
    return result
}

private fun makeMediaFile(context: Context, uri: Uri, video: Boolean): MediaFile? {
    val name = displayName(context, uri) ?: return null
    val ext = name.substringAfterLast('.', "").lowercase(Locale.US)
    if (video && ext !in VIDEO_EXT) return null
    if (!video && ext !in AUDIO_EXT) return null
    return MediaFile(uri, name, video)
}

private fun displayName(context: Context, uri: Uri): String? = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }

private fun persist(context: Context, uri: Uri) { try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {} }

private fun readInfo(context: Context, uri: Uri): MediaInfo {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(context, uri)
        val size = context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c -> if (c.moveToFirst()) c.getLong(0) else 0L } ?: 0L
        val duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.let { formatDuration(it) } ?: "未知"
        val mime = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: "未知"
        val v = findTrackMime(context, uri, true)
        val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH) ?: "?"
        val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT) ?: "?"
        val fps = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE) ?: "?"
        val a = findTrackMime(context, uri, false)
        val ar = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE) ?: "未知"
        return MediaInfo(formatSize(size), duration, mime, v, w, h, fps, a, if (ar == "未知") ar else "${ar.toLongOrNull()?.div(1000) ?: ar} kbps")
    } finally { r.release() }
}

private fun findTrackMime(context: Context, uri: Uri, video: Boolean): String {
    val extractor = android.media.MediaExtractor()
    return try {
        extractor.setDataSource(context, uri, null)
        val prefix = if (video) "video/" else "audio/"
        var result = "未知"
        for (i in 0 until extractor.trackCount) {
            val mime = extractor.getTrackFormat(i).getString(android.media.MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith(prefix)) {
                result = mime.substringAfter('/')
                break
            }
        }
        result
    } catch (_: Exception) {
        "未知"
    } finally {
        extractor.release()
    }
}

private fun formatSize(bytes: Long): String = when { bytes < 1024 -> "$bytes B"; bytes < 1024*1024 -> "%.1f KB".format(bytes/1024.0); bytes < 1024*1024*1024 -> "%.1f MB".format(bytes/1024.0/1024); else -> "%.2f GB".format(bytes/1024.0/1024/1024) }
private fun formatDuration(ms: Long): String { val s = ms / 1000; return "%02d:%02d:%02d".format(s/3600, (s%3600)/60, s%60) }

@Composable
private fun dynamicColorScheme(): ColorScheme = if (Build.VERSION.SDK_INT >= 31) dynamicLightColorScheme(LocalContext.current) else lightColorScheme()
