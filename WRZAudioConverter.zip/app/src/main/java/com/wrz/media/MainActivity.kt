package com.wrz.media

import android.Manifest
import android.content.*
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private val AUDIO_EXT = setOf("mp3","wav","flac","m4a","aac","ogg","opus","wma","aiff","aif","amr","mka","ape")
private val VIDEO_EXT = setOf("mp4","mkv","mov","webm","avi","flv","ts","m4v","3gp","wmv")
private const val SETTINGS = "wrz_media_settings"

data class MediaFile(val uri: Uri, val name: String, val isVideo: Boolean)
data class MediaInfo(val size: String, val duration: String, val mime: String, val videoCodec: String, val width: String, val height: String, val fps: String, val audioCodec: String, val audioRate: String)

data class AppSettings(val parallel: Int = 0, val defaultBitrate: Int = 192, val darkMode: Int = 0, val keepScreen: Boolean = false) {
    companion object {
        fun load(context: Context) = context.getSharedPreferences(SETTINGS, Context.MODE_PRIVATE).let { p -> AppSettings(p.getInt("parallel", 0), p.getInt("bitrate", 192), p.getInt("dark", 0), p.getBoolean("keep_screen", false)) }
        fun save(context: Context, s: AppSettings) = context.getSharedPreferences(SETTINGS, Context.MODE_PRIVATE).edit().putInt("parallel", s.parallel).putInt("bitrate", s.defaultBitrate).putInt("dark", s.darkMode).putBoolean("keep_screen", s.keepScreen).apply()
    }
}

class MainActivity : ComponentActivity() {
    private val progressState = mutableIntStateOf(0)
    private val progressText = mutableStateOf("")
    private val runningState = mutableStateOf(false)
    private val pausedState = mutableStateOf(false)
    private val taskModeState = mutableStateOf("")
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            progressState.intValue = intent?.getIntExtra("progress", 0) ?: 0
            progressText.value = intent?.getStringExtra("text") ?: ""
            taskModeState.value = intent?.getStringExtra("taskMode") ?: ""
            pausedState.value = intent?.getBooleanExtra("paused", false) ?: false
            runningState.value = !(intent?.getBooleanExtra("finished", false) ?: false) && !pausedState.value
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3001)
        ContextCompat.registerReceiver(this, receiver, IntentFilter(MediaProcessingService.ACTION_PROGRESS), ContextCompat.RECEIVER_NOT_EXPORTED)
        MediaProcessingService.savedTask(this)?.let { saved ->
            taskModeState.value = saved.mode
            pausedState.value = true
            runningState.value = false
            progressText.value = "有未完成任务，可继续断点任务"
        }
        setContent {
            val context = LocalContext.current
            var settings by remember { mutableStateOf(AppSettings.load(context)) }
            if (settings.keepScreen) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            WRZMediaApp(progressState, progressText, runningState, pausedState, taskModeState, settings, { settings = it; AppSettings.save(context, it) }) { task -> startTask(task) }
        }
    }

    private fun startTask(task: TaskData) {
        progressState.intValue = 0
        progressText.value = "正在启动后台任务…"
        taskModeState.value = task.mode
        pausedState.value = false
        runningState.value = true
        try { MediaProcessingService.start(this, task) } catch (e: Exception) {
            runningState.value = false
            progressText.value = "启动失败：${e.message ?: e.javaClass.simpleName}"
            android.widget.Toast.makeText(this, progressText.value, android.widget.Toast.LENGTH_LONG).show()
            return
        }
        Handler(Looper.getMainLooper()).postDelayed({
            if (runningState.value && progressText.value == "正在启动后台任务…") android.widget.Toast.makeText(this, "后台任务未返回状态，请检查通知权限和系统后台限制", android.widget.Toast.LENGTH_LONG).show()
        }, 6000L)
    }

    override fun onDestroy() { unregisterReceiver(receiver); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun WRZMediaApp(progress: State<Int>, progressText: State<String>, running: State<Boolean>, paused: State<Boolean>, taskMode: State<String>, settings: AppSettings, onSettings: (AppSettings) -> Unit, onStartTask: (TaskData) -> Unit) {
    val pager = rememberPagerState(initialPage = 0, pageCount = { 4 })
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val dark = when (settings.darkMode) { 1 -> true; 2 -> false; else -> null }
    val scheme = when (dark) { true -> darkColorScheme(); false -> lightColorScheme(); null -> if (Build.VERSION.SDK_INT >= 31) dynamicLightColorScheme(context) else lightColorScheme() }

    MaterialTheme(colorScheme = scheme) {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("WRZ Media") }, actions = {
                    if (taskMode.value.isNotBlank() && (running.value || paused.value)) {
                        Text(if (paused.value) "已暂停" else "${progress.value}%", modifier = Modifier.padding(end = 16.dp), color = MaterialTheme.colorScheme.primary)
                    }
                })
            },
            bottomBar = {
                GlassBottomBar(current = pager.currentPage, onSelect = { scope.launch { pager.animateScrollToPage(it) } })
            }
        ) { padding ->
            HorizontalPager(state = pager, modifier = Modifier.fillMaxSize().padding(padding), beyondViewportPageCount = 1) { page ->
                when (page) {
                    0 -> HomePage(progress, progressText, running, paused, taskMode, Modifier.fillMaxSize(), { mode -> scope.launch { pager.animateScrollToPage(1) } }, { scope.launch { pager.animateScrollToPage(2) } })
                    1 -> ConvertPage(progress, progressText, running, paused, taskMode, settings, Modifier.fillMaxSize(), onStartTask)
                    2 -> MergePage(progress, progressText, running, paused, taskMode, settings, Modifier.fillMaxSize(), onStartTask)
                    else -> SettingsPage(settings, onSettings, Modifier.fillMaxSize())
                }
            }
        }
    }
}

@Composable
private fun GlassBottomBar(current: Int, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp).clip(shape).background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.surface.copy(alpha = .82f), MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .68f))).also { it }).border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .28f), shape).padding(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf(Icons.Default.Home to "首页", Icons.Default.Transform to "转换", Icons.Default.Merge to "合并", Icons.Default.Settings to "设置").forEachIndexed { i, pair ->
                NavigationBarItem(selected = current == i, onClick = { onSelect(i) }, icon = { Icon(pair.first, null) }, label = { Text(pair.second) }, alwaysShowLabel = true)
            }
        }
    }
}

@Composable
private fun HomePage(progress: State<Int>, text: State<String>, running: State<Boolean>, paused: State<Boolean>, taskMode: State<String>, modifier: Modifier, onConvert: (String) -> Unit, onMerge: () -> Unit) {
    Column(modifier.padding(16.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("本地媒体工具", style = MaterialTheme.typography.headlineSmall)
                Text("FFmpeg 本地处理 · 无广告 · 无会员 · 不上传文件", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (taskMode.value.isNotBlank() && (running.value || paused.value || text.value.isNotBlank())) {
                    Spacer(Modifier.height(8.dp)); Text("当前任务：${if (taskMode.value == "audio") "音频转换" else if (taskMode.value == "video") "视频转换" else "音视频合并"}")
                    Text(if (paused.value) "已暂停，可从断点继续" else text.value.ifBlank { "正在处理" }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (!paused.value && running.value) LinearProgressIndicator({ progress.value / 100f }, Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (running.value) OutlinedButton(onClick = { MediaProcessingService.pause(LocalContext.current) }) { Text("暂停") }
                        if (paused.value) Button(onClick = { MediaProcessingService.resume(LocalContext.current) }) { Text("继续") }
                        if (running.value || paused.value) OutlinedButton(onClick = { MediaProcessingService.cancel(LocalContext.current) }) { Text("取消") }
                    }
                }
            }
        }
        FeatureCard("🎵", "音频转换", "批量、文件夹、MP3 / AAC / FLAC / OPUS / WAV", "打开") { onConvert("音频") }
        FeatureCard("🎬", "视频转换", "H.264 / H.265 / 原编码复制 · 原参数可见", "打开") { onConvert("视频") }
        FeatureCard("🎞️", "音视频合并", "替换音轨，视频流默认直接复制", "打开", onMerge)
        Text("支持左右滑动切页；底部导航仍然保留。", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable private fun FeatureCard(icon: String, title: String, desc: String, tag: String, onClick: () -> Unit) {
    Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Text(icon, style = MaterialTheme.typography.headlineMedium); Spacer(Modifier.width(16.dp)); Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.titleLarge); Text(desc, color = MaterialTheme.colorScheme.onSurfaceVariant) }; AssistChip(onClick = onClick, label = { Text(tag) }) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConvertPage(progress: State<Int>, progressText: State<String>, running: State<Boolean>, paused: State<Boolean>, taskMode: State<String>, settings: AppSettings, modifier: Modifier, onStartTask: (TaskData) -> Unit) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf("音频") }
    var files by remember { mutableStateOf(listOf<MediaFile>()) }
    var outputTree by remember { mutableStateOf<Uri?>(null) }
    var audioExt by remember { mutableStateOf("mp3") }
    var bitrate by remember(settings.defaultBitrate) { mutableIntStateOf(settings.defaultBitrate) }
    var codec by remember { mutableStateOf("H.264 / AVC") }
    var crf by remember { mutableIntStateOf(23) }
    var preset by remember { mutableStateOf("medium") }
    var selectedVideo by remember { mutableStateOf<MediaFile?>(null) }
    val scope = rememberCoroutineScope()
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> files = (files + uris.mapNotNull { makeMediaFile(context, it, mode == "视频") }).distinctBy { it.uri.toString() }; if (mode == "视频") selectedVideo = files.firstOrNull { it.isVideo } }
    val inputFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) { persist(context, uri); scope.launch(Dispatchers.IO) { val found = scanFolder(context, uri, mode == "视频"); withContext(Dispatchers.Main) { files = (files + found).distinctBy { it.uri.toString() }; if (mode == "视频") selectedVideo = files.firstOrNull { it.isVideo } } } } }
    val outputFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) { persist(context, uri); outputTree = uri } }
    val info by produceState<MediaInfo?>(null, selectedVideo?.uri) { value = selectedVideo?.let { withContext(Dispatchers.IO) { readInfo(context, it.uri) } } }
    val active = taskMode.value == if (mode == "音频") "audio" else "video"
    Column(modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) { listOf("音频", "视频").forEachIndexed { i, s -> SegmentedButton(mode == s, { mode = s; files = emptyList(); selectedVideo = null }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(s) } } }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = { filePicker.launch(arrayOf(if (mode == "视频") "video/*" else "audio/*")) }) { Icon(Icons.Default.AttachFile, null); Spacer(Modifier.width(6.dp)); Text("选择文件") }; OutlinedButton(onClick = { inputFolderPicker.launch(null) }) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(6.dp)); Text("添加文件夹") } }
        OutlinedButton(onClick = { outputFolderPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Output, null); Spacer(Modifier.width(6.dp)); Text("输出目录：${if (outputTree == null) "请选择" else "已选择"}") }
        if (mode == "视频" && selectedVideo != null) { VideoPreview(selectedVideo!!.uri); info?.let { InfoCard(it) } }
        if (mode == "音频") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Dropdown(audioExt, listOf("mp3","m4a","aac","flac","wav","ogg","opus")) { audioExt = it }; if (audioExt !in setOf("flac","wav")) Dropdown("${bitrate} kbps", listOf("96 kbps","128 kbps","160 kbps","192 kbps","224 kbps","256 kbps","320 kbps")) { bitrate = it.substringBefore(' ').toInt() } }
        } else {
            Dropdown(codec, listOf("H.264 / AVC","H.265 / HEVC","复制原视频流")) { codec = it }
            if (codec != "复制原视频流") { Text("CRF：$crf（越小质量越高、体积越大）"); Slider(value = crf.toFloat(), onValueChange = { crf = it.toInt() }, valueRange = 16f..30f, steps = 13); Dropdown("Preset：$preset", listOf("ultrafast","fast","medium","slow","veryslow")) { preset = it.substringAfter(": ") }; Dropdown("AAC ${bitrate} kbps", listOf("96 kbps","128 kbps","160 kbps","192 kbps","256 kbps")) { bitrate = it.substringBefore(' ').toInt() } }
            Text("实际参数：-c:v ${if (codec == "H.264 / AVC") "libx264" else if (codec == "H.265 / HEVC") "libx265" else "copy"} ${if (codec == "复制原视频流") "-c:a copy" else "-crf $crf -preset $preset -c:a aac -b:a ${bitrate}k"}", style = MaterialTheme.typography.bodySmall)
        }
        Text("已选 ${files.size} 个文件 · 并行：${parallelLabel(settings.parallel)}", style = MaterialTheme.typography.titleMedium)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) { items(files) { Text("• ${it.name}", maxLines = 1) } }
        if (active && (running.value || paused.value || progressText.value.isNotBlank())) TaskCard(progress, progressText, running, paused)
        Button(enabled = files.isNotEmpty() && outputTree != null && (!running.value || !active), onClick = { val task = if (mode == "音频") TaskData("audio", "WRZ Media · 音频转换", files.map { it.uri.toString() }, files.map { it.name }, outputTree.toString(), audioExt, bitrate) else TaskData("video", "WRZ Media · 视频转换", files.map { it.uri.toString() }, files.map { it.name }, outputTree.toString(), bitrate = bitrate, videoCodec = codec, crf = crf, preset = preset); onStartTask(task) }, modifier = Modifier.fillMaxWidth()) { Text(if (active && running.value) "转换中… ${progress.value}%" else if (active && paused.value) "已暂停 · 从断点继续" else "开始转换") }
    }
}

@Composable private fun TaskCard(progress: State<Int>, text: State<String>, running: State<Boolean>, paused: State<Boolean>) { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text(if (paused.value) "已暂停" else text.value.ifBlank { "准备中…" }); if (!paused.value && running.value) LinearProgressIndicator({ progress.value / 100f }, Modifier.fillMaxWidth()); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { if (running.value) OutlinedButton(onClick = { MediaProcessingService.pause(LocalContext.current) }) { Text("暂停") }; if (paused.value) Button(onClick = { MediaProcessingService.resume(LocalContext.current) }) { Text("继续") }; if (running.value || paused.value) OutlinedButton(onClick = { MediaProcessingService.cancel(LocalContext.current) }) { Text("取消") } } } } }

@Composable
private fun MergePage(progress: State<Int>, progressText: State<String>, running: State<Boolean>, paused: State<Boolean>, taskMode: State<String>, settings: AppSettings, modifier: Modifier, onStartTask: (TaskData) -> Unit) {
    val context = LocalContext.current; var video by remember { mutableStateOf<MediaFile?>(null) }; var audio by remember { mutableStateOf<MediaFile?>(null) }; var output by remember { mutableStateOf<Uri?>(null) }; var bitrate by remember(settings.defaultBitrate) { mutableIntStateOf(settings.defaultBitrate) }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let { video = makeMediaFile(context, it, true) } }; val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let { audio = makeMediaFile(context, it, false) } }; val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let { persist(context, it); output = it } }
    val active = taskMode.value == "merge"
    Column(modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("音视频合并", style = MaterialTheme.typography.headlineSmall)
        OutlinedButton(onClick = { videoPicker.launch(arrayOf("video/*")) }, Modifier.fillMaxWidth()) { Text("视频：${video?.name ?: "选择视频"}") }
        OutlinedButton(onClick = { audioPicker.launch(arrayOf("audio/*")) }, Modifier.fillMaxWidth()) { Text("音频：${audio?.name ?: "选择音频"}") }
        OutlinedButton(onClick = { folderPicker.launch(null) }, Modifier.fillMaxWidth()) { Text("输出目录：${if (output == null) "选择" else "已选择"}") }
        Dropdown("AAC ${bitrate} kbps", listOf("96 kbps","128 kbps","160 kbps","192 kbps","256 kbps")) { bitrate = it.substringBefore(' ').toInt() }
        Text("视频流默认 copy，不重新压缩；音频重新编码为 AAC。", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (active && (running.value || paused.value || progressText.value.isNotBlank())) TaskCard(progress, progressText, running, paused)
        Button(enabled = video != null && audio != null && output != null && (!running.value || !active), onClick = { onStartTask(TaskData("merge", "WRZ Media · 音视频合并", listOf(video!!.uri.toString(), audio!!.uri.toString()), listOf(video!!.name, audio!!.name), output.toString(), bitrate = bitrate, mergeName = video!!.name.substringBeforeLast('.') + "_merged.mp4")) }, modifier = Modifier.fillMaxWidth()) { Text(if (active && running.value) "合并中… ${progress.value}%" else if (active && paused.value) "已暂停 · 继续合并" else "开始合并") }
    }
}

@Composable
private fun SettingsPage(settings: AppSettings, onChange: (AppSettings) -> Unit, modifier: Modifier) {
    Column(modifier.padding(16.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("设置", style = MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text("WRZ Media 2.0", style = MaterialTheme.typography.titleLarge); Text("本地 FFmpeg · Android 原生界面 · 无上传", color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        SettingDropdown("并行转换任务", parallelLabel(settings.parallel), listOf("自动", "1 路", "2 路", "3 路", "4 路")) { v -> onChange(settings.copy(parallel = if (v == "自动") 0 else v.substringBefore(' ').toInt())) }
        SettingDropdown("默认音频码率", "${settings.defaultBitrate} kbps", listOf("96 kbps","128 kbps","160 kbps","192 kbps","224 kbps","256 kbps","320 kbps")) { onChange(settings.copy(defaultBitrate = it.substringBefore(' ').toInt())) }
        SettingDropdown("外观", when(settings.darkMode) { 1 -> "深色"; 2 -> "浅色"; else -> "跟随系统" }, listOf("跟随系统","深色","浅色")) { onChange(settings.copy(darkMode = when(it) { "深色" -> 1; "浅色" -> 2; else -> 0 })) }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("转换时保持屏幕常亮"); Text("只在前台查看设置时有用，后台任务仍由前台服务维持", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall) }; Switch(settings.keepScreen, { onChange(settings.copy(keepScreen = it)) }) }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text("后台任务", style = MaterialTheme.typography.titleMedium); Text("暂停会保存已完成文件的索引；继续时从未完成的文件开始。当前正在转换的那个文件如果暂停，会重新处理该文件。", color = MaterialTheme.colorScheme.onSurfaceVariant); Text("并行任务数越高，CPU、内存和发热越高。建议 2 路。", color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text("小米超级岛", style = MaterialTheme.typography.titleMedium); Text("已按 Xiaomi HyperOS 官方 miui.focus.param / param_v2 结构发送进度通知。是否真正上岛还取决于系统版本、焦点通知权限和小米侧场景权限。", color = MaterialTheme.colorScheme.onSurfaceVariant) } }
    }
}

@Composable private fun SettingDropdown(title: String, value: String, options: List<String>, onPick: (String) -> Unit) { Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title); Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Dropdown(value, options, onPick) } } }
private fun parallelLabel(v: Int) = if (v == 0) "自动" else "$v 路"

@Composable private fun VideoPreview(uri: Uri) { val context = LocalContext.current; val player = remember(uri) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(uri)); prepare() } }; DisposableEffect(player) { onDispose { player.release() } }; AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } }, Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(18.dp))) }
@Composable private fun InfoCard(info: MediaInfo) { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) { Text("原始媒体参数", style = MaterialTheme.typography.titleMedium); Text("文件：${info.size} · 时长：${info.duration} · MIME：${info.mime}"); Text("视频：${info.videoCodec} · ${info.width}×${info.height} · ${info.fps} FPS"); Text("音频：${info.audioCodec} · ${info.audioRate}") } } }
@Composable private fun Dropdown(value: String, options: List<String>, onPick: (String) -> Unit) { var expanded by remember { mutableStateOf(false) }; Box { OutlinedButton(onClick = { expanded = true }) { Text(value); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(expanded, { expanded = false }) { options.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { onPick(it); expanded = false }) } } } }

private fun scanFolder(context: Context, treeUri: Uri, video: Boolean): List<MediaFile> { val root = DocumentFile.fromTreeUri(context, treeUri) ?: return emptyList(); val result = mutableListOf<MediaFile>(); fun walk(dir: DocumentFile) { dir.listFiles().forEach { file -> if (file.isDirectory) walk(file) else if (file.isFile) makeMediaFile(context, file.uri, video)?.let { result += it } } }; walk(root); return result }
private fun makeMediaFile(context: Context, uri: Uri, video: Boolean): MediaFile? { val name = displayName(context, uri) ?: return null; val ext = name.substringAfterLast('.', "").lowercase(Locale.US); if (video && ext !in VIDEO_EXT) return null; if (!video && ext !in AUDIO_EXT) return null; return MediaFile(uri, name, video) }
private fun displayName(context: Context, uri: Uri): String? = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
private fun persist(context: Context, uri: Uri) { try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {} }
private fun readInfo(context: Context, uri: Uri): MediaInfo { val r = MediaMetadataRetriever(); try { r.setDataSource(context, uri); val size = context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c -> if (c.moveToFirst()) c.getLong(0) else 0L } ?: 0L; val duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.let { formatDuration(it) } ?: "未知"; val mime = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: "未知"; val v = findTrackMime(context, uri, true); val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH) ?: "?"; val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT) ?: "?"; val fps = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE) ?: "?"; val a = findTrackMime(context, uri, false); val ar = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE) ?: "未知"; return MediaInfo(formatSize(size), duration, mime, v, w, h, fps, a, if (ar == "未知") ar else "${ar.toLongOrNull()?.div(1000) ?: ar} kbps") } finally { r.release() } }
private fun findTrackMime(context: Context, uri: Uri, video: Boolean): String { val extractor = android.media.MediaExtractor(); return try { extractor.setDataSource(context, uri, null); val prefix = if (video) "video/" else "audio/"; var result = "未知"; for (i in 0 until extractor.trackCount) { val mime = extractor.getTrackFormat(i).getString(android.media.MediaFormat.KEY_MIME) ?: continue; if (mime.startsWith(prefix)) { result = mime.substringAfter('/'); break } }; result } catch (_: Exception) { "未知" } finally { extractor.release() } }
private fun formatSize(bytes: Long): String = when { bytes < 1024 -> "$bytes B"; bytes < 1024*1024 -> "%.1f KB".format(bytes/1024.0); bytes < 1024*1024*1024 -> "%.1f MB".format(bytes/1024.0/1024); else -> "%.2f GB".format(bytes/1024.0/1024/1024) }
private fun formatDuration(ms: Long): String { val s = ms / 1000; return "%02d:%02d:%02d".format(s/3600, (s%3600)/60, s%60) }
