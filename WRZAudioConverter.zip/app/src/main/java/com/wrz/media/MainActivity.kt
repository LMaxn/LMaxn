package com.wrz.media

import android.Manifest
import android.content.*
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.AudioAttributes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

private val AUDIO_EXT = setOf("mp3","wav","flac","m4a","aac","ogg","opus","wma","aiff","aif","amr","mka","ape")
private val VIDEO_EXT = setOf("mp4","mkv","mov","webm","avi","flv","ts","m4v","3gp","wmv")
private const val SETTINGS = "wrz_media_settings"

data class MediaFile(val uri: Uri, val name: String, val isVideo: Boolean)
data class MediaInfo(val size: String, val duration: String, val mime: String, val videoCodec: String, val width: String, val height: String, val fps: String, val audioCodec: String, val audioRate: String)

data class ConvertUiState(
    val audioFiles: List<MediaFile> = emptyList(),
    val videoFiles: List<MediaFile> = emptyList(),
    val audioOutputTree: Uri? = null,
    val videoOutputTree: Uri? = null,
    val audioExt: String = "mp3",
    val bitrate: Int = 192,
    val codec: String = "H.264 / AVC",
    val videoExt: String = "mp4",
    val crf: Int = 23,
    val preset: String = "medium",
    val selectedVideoIndex: Int = 0
)


data class AppSettings(val parallel: Int = 0, val defaultBitrate: Int = 192, val darkMode: Int = 0, val keepScreen: Boolean = false) {
    companion object {
        fun load(context: Context) = context.getSharedPreferences(SETTINGS, Context.MODE_PRIVATE).let { p -> AppSettings(p.getInt("parallel", 0), p.getInt("bitrate", 192), p.getInt("dark", 0), p.getBoolean("keep_screen", false)) }
        fun save(context: Context, s: AppSettings) = context.getSharedPreferences(SETTINGS, Context.MODE_PRIVATE).edit().putInt("parallel", s.parallel).putInt("bitrate", s.defaultBitrate).putInt("dark", s.darkMode).putBoolean("keep_screen", s.keepScreen).apply()
    }
}

class MainActivity : ComponentActivity() {
    private val progressState = mutableIntStateOf(0)
    private val progressText = mutableStateOf("")
    private val runningState = mutableStateOf(false)
    private val pausedState = mutableStateOf(false)
    private val taskModeState = mutableStateOf("")
    private val completedState = mutableStateOf<Set<Int>>(emptySet())
    private val currentIndexState = mutableIntStateOf(-1)
    private val currentFileProgressState = mutableIntStateOf(0)
    private val taskFinishedState = mutableStateOf(false)
    private val taskErrorState = mutableStateOf(false)
    private val taskDismissedState = mutableStateOf(false)
    private val pauseCommandInFlight = AtomicBoolean(false)
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            progressState.intValue = intent?.getIntExtra("progress", 0) ?: 0
            progressText.value = intent?.getStringExtra("text") ?: ""
            taskModeState.value = intent?.getStringExtra("taskMode") ?: ""
            pausedState.value = intent?.getBooleanExtra("paused", false) ?: false
            taskFinishedState.value = intent?.getBooleanExtra("finished", false) ?: false
            taskErrorState.value = intent?.getBooleanExtra("error", false) ?: false
            if (pausedState.value || taskFinishedState.value) pauseCommandInFlight.set(false)
            completedState.value = (intent?.getStringExtra("completed") ?: "").split(",").mapNotNull { it.toIntOrNull() }.toSet()
            currentIndexState.intValue = intent?.getIntExtra("currentIndex", -1) ?: -1
            currentFileProgressState.intValue = intent?.getIntExtra("currentFileProgress", 0) ?: 0
            runningState.value = !taskFinishedState.value && !pausedState.value
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3001)
        ContextCompat.registerReceiver(this, receiver, IntentFilter(MediaProcessingService.ACTION_PROGRESS), ContextCompat.RECEIVER_NOT_EXPORTED)
        MediaProcessingService.savedTask(this)?.let { saved ->
            taskModeState.value = saved.mode
            pausedState.value = true
            runningState.value = false
            completedState.value = MediaProcessingService.savedCompleted(this)
            progressText.value = "有未完成任务，可继续断点任务"
        }
        setContent {
            val context = LocalContext.current
            var settings by remember { mutableStateOf(AppSettings.load(context)) }
            if (settings.keepScreen) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            WRZMediaApp(progressState, progressText, runningState, pausedState, taskFinishedState, taskErrorState, taskDismissedState, taskModeState, completedState, currentIndexState, currentFileProgressState, settings, { settings = it; AppSettings.save(context, it) }, { pauseTaskNow() }, { resumeTaskNow() }, { taskDismissedState.value = true }) { task -> startTask(task) }
        }
    }

    private fun startTask(task: TaskData) {
        progressState.intValue = 0
        progressText.value = "正在启动后台任务…"
        taskModeState.value = task.mode
        completedState.value = emptySet()
        currentIndexState.intValue = -1
        currentFileProgressState.intValue = 0
        pausedState.value = false
        taskFinishedState.value = false
        taskErrorState.value = false
        taskDismissedState.value = false
        runningState.value = true
        try { MediaProcessingService.start(this, task) } catch (e: Exception) {
            runningState.value = false
            taskFinishedState.value = true
            taskErrorState.value = true
            taskDismissedState.value = false
            progressText.value = "启动失败：${e.message ?: e.javaClass.simpleName}"
            android.widget.Toast.makeText(this, progressText.value, android.widget.Toast.LENGTH_LONG).show()
            return
        }
        Handler(Looper.getMainLooper()).postDelayed({
            if (runningState.value && progressText.value == "正在启动后台任务…") android.widget.Toast.makeText(this, "后台任务未返回状态，请检查通知权限和系统后台限制", android.widget.Toast.LENGTH_LONG).show()
        }, 6000L)
    }

    private fun pauseTaskNow() {
        if (!pauseCommandInFlight.compareAndSet(false, true)) return
        pausedState.value = true
        runningState.value = false
        progressText.value = "正在暂停… · 正在保存断点"
        MediaProcessingService.pause(this)
    }

    private fun resumeTaskNow() {
        if (!pausedState.value && MediaProcessingService.savedTask(this) == null) return
        pauseCommandInFlight.set(false)
        pausedState.value = false
        runningState.value = true
        progressText.value = "正在继续… · 从断点恢复"
        MediaProcessingService.resume(this)
    }

    override fun onDestroy() { unregisterReceiver(receiver); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun WRZMediaApp(progress: State<Int>, progressText: State<String>, running: State<Boolean>, paused: State<Boolean>, finished: State<Boolean>, taskError: State<Boolean>, taskDismissed: State<Boolean>, taskMode: State<String>, completed: State<Set<Int>>, currentIndex: State<Int>, currentFileProgress: State<Int>, settings: AppSettings, onSettings: (AppSettings) -> Unit, onPauseTask: () -> Unit, onResumeTask: () -> Unit, onDismissTask: () -> Unit, onStartTask: (TaskData) -> Unit) {
    var requestedConvertMode by remember { mutableStateOf("音频") }
    var convertState by remember { mutableStateOf(ConvertUiState(bitrate = settings.defaultBitrate)) }
    val pager = rememberPagerState(initialPage = 0, pageCount = { 4 })
    val scope = rememberCoroutineScope()
    // 启动阶段先不预加载相邻页面，避免首屏与视频/媒体组件同时抢主线程；
    // 首屏稳定后再轻量预热相邻页面，让后续 Dock 动画更顺滑。
    var pagerPreload by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(900L)
        pagerPreload = 1
    }
    val context = LocalContext.current
    val systemDark = isSystemInDarkTheme()
    val dark = when (settings.darkMode) { 1 -> true; 2 -> false; else -> systemDark }
    // 保持 WRZ Media 自己的紫色风格：跟随系统只决定明暗，不使用系统动态取色。
    val scheme = if (dark) {
        darkColorScheme(
            primary = Color(0xFFD0BCFF),
            onPrimary = Color(0xFF381E72),
            primaryContainer = Color(0xFF4F378B),
            onPrimaryContainer = Color(0xFFEADDFF),
            surface = Color(0xFF141218),
            surfaceVariant = Color(0xFF49454F),
            background = Color(0xFF141218)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF6750A4),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFEADDFF),
            onPrimaryContainer = Color(0xFF21005D),
            surface = Color(0xFFFFFBFE),
            surfaceVariant = Color(0xFFE7E0EC),
            background = Color(0xFFFFFBFE)
        )
    }

    MaterialTheme(colorScheme = scheme) {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("WRZ Media") }, actions = {
                    if (taskMode.value.isNotBlank() && (running.value || paused.value)) {
                        Text(if (paused.value) "已暂停" else "${progress.value}%", modifier = Modifier.padding(end = 16.dp), color = MaterialTheme.colorScheme.primary)
                    }
                })
            },
            bottomBar = {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    GlassBottomBar(current = pager.currentPage, pageOffset = pager.currentPageOffsetFraction, onSelect = { page ->
                        scope.launch { pager.animateScrollToPage(page) }
                    })
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                HorizontalPager(
                    state = pager,
                    modifier = Modifier.fillMaxSize(),
                    // 启动最初阶段只组合当前页；约 0.9 秒后预热相邻页，
                    // 让刚打开应用时 Dock 能先响应，稳定后再获得顺滑的相邻页切换。
                    beyondViewportPageCount = pagerPreload
                ) { page ->
                    when (page) {
                        0 -> HomePage(progress, progressText, running, paused, taskMode, Modifier.fillMaxSize(), { requestedConvertMode = it; scope.launch { pager.animateScrollToPage(1) } }, { scope.launch { pager.animateScrollToPage(2) } }, onPauseTask, onResumeTask)
                        1 -> ConvertPage(progress, progressText, running, paused, taskMode, completed, currentIndex, currentFileProgress, settings, requestedConvertMode, { requestedConvertMode = it }, convertState, { convertState = it }, Modifier.fillMaxSize(), onStartTask)
                        2 -> MergePage(progress, progressText, running, paused, taskMode, settings, Modifier.fillMaxSize(), onStartTask)
                        else -> SettingsPage(settings, onSettings, Modifier.fillMaxSize())
                    }
                }
                // 转换进度固定悬浮在底部导航栏上方，不再要求用户滚到页面最底部。
                val showTaskCard = taskMode.value.isNotBlank() && !taskDismissed.value && (running.value || paused.value || (finished.value && taskError.value))
                if (showTaskCard) {
                    TaskCard(
                        progress, progressText, running, paused, finished, taskError, onPauseTask, onResumeTask, onDismissTask,
                        Modifier.align(Alignment.BottomCenter).padding(start = 16.dp, end = 8.dp, bottom = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun GlassBottomBar(
    current: Int,
    pageOffset: Float,
    onSelect: (Int) -> Unit
) {
    val selected = current.coerceIn(0, 3)
    Surface(
        modifier = Modifier
            .navigationBarsPadding()
            .padding(bottom = 12.dp)
            .size(width = 344.dp, height = 76.dp),
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 2.dp,
        shadowElevation = 0.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val items = listOf(
                Triple(Icons.Default.Home, "首页", 0),
                Triple(Icons.Default.Transform, "转换", 1),
                Triple(Icons.Default.Merge, "合并", 2),
                Triple(Icons.Default.Settings, "设置", 3)
            )
            items.forEach { (icon, label, page) ->
                val active = selected == page
                Surface(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .clickable { onSelect(page) },
                    shape = CircleShape,
                    color = if (active) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                    tonalElevation = 0.dp,
                    shadowElevation = 0.dp
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(icon, contentDescription = label, tint = if (active) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(label, style = MaterialTheme.typography.labelSmall, color = if (active) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun HomePage(progress: State<Int>, text: State<String>, running: State<Boolean>, paused: State<Boolean>, taskMode: State<String>, modifier: Modifier, onConvert: (String) -> Unit, onMerge: () -> Unit, onPauseTask: () -> Unit, onResumeTask: () -> Unit) {
    val context = LocalContext.current
    Column(modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("本地媒体工具", style = MaterialTheme.typography.headlineSmall)
                Text("FFmpeg 本地处理 · 无广告 · 无会员 · 不上传文件", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (taskMode.value.isNotBlank() && (running.value || paused.value)) {
                    Spacer(Modifier.height(8.dp)); Text("当前任务：${if (taskMode.value == "audio") "音频转换" else if (taskMode.value == "video") "视频转换" else "音视频合并"}")
                    Text(if (paused.value) "已暂停，可从断点继续" else text.value.ifBlank { "正在处理" }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    LinearProgressIndicator({ progress.value.coerceIn(0, 100) / 100f }, Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (running.value) OutlinedButton(onClick = onPauseTask) { Text("暂停") }
                        if (paused.value) Button(onClick = onResumeTask) { Text("继续") }
                        if (running.value || paused.value) OutlinedButton(onClick = { MediaProcessingService.cancel(context) }) { Text("取消") }
                    }
                }
            }
        }
        FeatureCard("🎵", "音频转换", "批量、文件夹、MP3 / AAC / FLAC / OPUS / WAV") { onConvert("音频") }
        FeatureCard("🎬", "视频转换", "H.264 / H.265 / 原编码复制 · 原参数可见") { onConvert("视频") }
        FeatureCard("🎞️", "音视频合并", "替换音轨，视频流默认直接复制", onMerge)
    }
}

@Composable private fun FeatureCard(icon: String, title: String, desc: String, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 92.dp)
                .padding(horizontal = 20.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(54.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(icon, style = MaterialTheme.typography.headlineSmall)
                }
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                Text(desc, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
private fun presetLabel(value: String): String = when (value) {
    "ultrafast" -> "极快（ultrafast）"
    "fast" -> "较快（fast）"
    "medium" -> "平衡（medium）"
    "slow" -> "较慢（slow）"
    else -> "极慢（veryslow）"
}

private fun videoCodecLabel(value: String): String = when (value) {
    "H.264 / AVC" -> "H.264 / AVC（MediaCodec 硬件）"
    "H.265 / HEVC" -> "H.265 / HEVC（MediaCodec 硬件）"
    "AV1" -> "AV1（libaom-av1）"
    "VP9" -> "VP9（libvpx-vp9）"
    "VP8" -> "VP8（libvpx）"
    "MPEG-4" -> "MPEG-4 Part 2（mpeg4）"
    "MPEG-2" -> "MPEG-2 Video（mpeg2video）"
    else -> "复制原视频流（copy）"
}

@Composable
private fun ConvertPage(
    progress: State<Int>,
    progressText: State<String>,
    running: State<Boolean>,
    paused: State<Boolean>,
    taskMode: State<String>,
    completed: State<Set<Int>>,
    currentIndex: State<Int>,
    currentFileProgress: State<Int>,
    settings: AppSettings,
    mode: String,
    onModeChange: (String) -> Unit,
    state: ConvertUiState,
    onStateChange: (ConvertUiState) -> Unit,
    modifier: Modifier,
    onStartTask: (TaskData) -> Unit
) {
    val context = LocalContext.current
    val files = if (mode == "视频") state.videoFiles else state.audioFiles
    val outputTree = if (mode == "视频") state.videoOutputTree else state.audioOutputTree
    val selectedVideo = state.videoFiles.getOrNull(state.selectedVideoIndex)
    val scope = rememberCoroutineScope()

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val picked = uris.mapNotNull { makeMediaFile(context, it, mode == "视频") }
        if (picked.isNotEmpty()) {
            if (mode == "视频") {
                val merged = (state.videoFiles + picked).distinctBy { it.uri.toString() }
                onStateChange(state.copy(videoFiles = merged, selectedVideoIndex = (merged.size - 1).coerceAtLeast(0)))
            } else {
                onStateChange(state.copy(audioFiles = (state.audioFiles + picked).distinctBy { it.uri.toString() }))
            }
        }
    }
    val inputFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            persist(context, uri)
            scope.launch(Dispatchers.IO) {
                val found = scanFolder(context, uri, mode == "视频")
                withContext(Dispatchers.Main) {
                    if (mode == "视频") {
                        val merged = (state.videoFiles + found).distinctBy { it.uri.toString() }
                        onStateChange(state.copy(videoFiles = merged, selectedVideoIndex = (merged.size - 1).coerceAtLeast(0)))
                    } else {
                        onStateChange(state.copy(audioFiles = (state.audioFiles + found).distinctBy { it.uri.toString() }))
                    }
                }
            }
        }
    }
    val outputFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            persist(context, uri)
            onStateChange(if (mode == "视频") state.copy(videoOutputTree = uri) else state.copy(audioOutputTree = uri))
        }
    }
    val info by produceState<MediaInfo?>(null, selectedVideo?.uri) {
        value = selectedVideo?.let { withContext(Dispatchers.IO) { readInfo(context, it.uri) } }
    }
    val active = taskMode.value == if (mode == "音频") "audio" else "video"

    Box(modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 150.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                listOf("音频", "视频").forEachIndexed { i, s ->
                    SegmentedButton(
                        selected = mode == s,
                        onClick = { onModeChange(s) },
                        shape = SegmentedButtonDefaults.itemShape(i, 2)
                    ) { Text(s) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { filePicker.launch(arrayOf(if (mode == "视频") "video/*" else "audio/*")) }) {
                    Icon(Icons.Default.AttachFile, null); Spacer(Modifier.width(6.dp)); Text("选择文件")
                }
                OutlinedButton(onClick = { inputFolderPicker.launch(null) }) {
                    Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(6.dp)); Text("添加文件夹")
                }
            }
            OutlinedButton(onClick = { outputFolderPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Output, null); Spacer(Modifier.width(6.dp)); Text("输出目录：${if (outputTree == null) "请选择" else "已选择"}")
            }
            if (mode == "视频" && selectedVideo != null) {
                if (files.size > 1) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            enabled = state.selectedVideoIndex > 0,
                            onClick = { onStateChange(state.copy(selectedVideoIndex = state.selectedVideoIndex - 1)) },
                            modifier = Modifier.size(width = 48.dp, height = 44.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) { Icon(Icons.Default.ChevronLeft, "上一个视频") }
                        Surface(
                            Modifier.weight(1f),
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerLow
                        ) {
                            Text(
                                "${state.selectedVideoIndex + 1} / ${files.size}  ·  ${selectedVideo.name}",
                                Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                maxLines = 1
                            )
                        }
                        OutlinedButton(
                            enabled = state.selectedVideoIndex < files.lastIndex,
                            onClick = { onStateChange(state.copy(selectedVideoIndex = state.selectedVideoIndex + 1)) },
                            modifier = Modifier.size(width = 48.dp, height = 44.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) { Icon(Icons.Default.ChevronRight, "下一个视频") }
                    }
                }
                key(selectedVideo.uri.toString()) { VideoPreview(selectedVideo.uri) }
                info?.let { InfoCard(it) }
            }
            if (mode == "音频") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Dropdown(state.audioExt, listOf("mp3","m4a","aac","flac","wav","ogg","opus")) { onStateChange(state.copy(audioExt = it)) }
                    if (state.audioExt !in setOf("flac", "wav")) {
                        Dropdown("${state.bitrate} kbps", listOf("96 kbps","128 kbps","160 kbps","192 kbps","224 kbps","256 kbps","320 kbps")) { onStateChange(state.copy(bitrate = it.substringBefore(' ').toInt())) }
                    }
                }
            } else {
                Text("视频转换参数", style = MaterialTheme.typography.titleMedium)
                Dropdown(state.codec, listOf("H.264 / AVC","H.265 / HEVC","AV1","VP9","VP8","MPEG-4","MPEG-2","复制原视频流")) {
                    val newExt = when (it) { "AV1", "VP9", "VP8" -> "webm"; "MPEG-2" -> "ts"; else -> "mp4" }
                    onStateChange(state.copy(codec = it, videoExt = newExt))
                }
                val videoExts = when (state.codec) {
                    "AV1" -> listOf("webm", "mkv", "mp4")
                    "VP9", "VP8" -> listOf("webm", "mkv")
                    "MPEG-2" -> listOf("ts", "mpg", "mkv")
                    "复制原视频流" -> listOf("mp4", "mkv", "mov", "ts", "avi", "webm", "flv")
                    else -> listOf("mp4", "mkv", "mov", "ts", "avi", "flv")
                }
                Dropdown("输出格式：.${state.videoExt}", videoExts.map { ".${it}" }) { onStateChange(state.copy(videoExt = it.removePrefix("."))) }
                Text(
                    when (state.codec) {
                        "H.264 / AVC" -> "H.264（AVC）：兼容性较好，适合手机、微信、网页等。"
                        "H.265 / HEVC" -> "H.265（HEVC）：压缩效率更高，通常比 H.264 更省空间。"
                        "AV1" -> "AV1：压缩效率很高，适合追求更小体积；编码通常更慢。"
                        "VP9" -> "VP9：常用于 WebM，适合网页和部分流媒体场景。"
                        "VP8" -> "VP8：较老的 WebM 视频编码，兼容性取决于播放器。"
                        "MPEG-4" -> "MPEG-4 Part 2：传统视频编码，兼容一些老设备和旧文件。"
                        "MPEG-2" -> "MPEG-2：传统广播/DVD 类编码，文件通常较大。"
                        else -> "复制原视频流：不重新编码，速度最快、画质不变，但原编码必须适合目标容器。"
                    },
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
                if (state.codec != "复制原视频流") {
                    if (state.codec == "H.264 / AVC" || state.codec == "H.265 / HEVC") {
                        Text("编码方式：手机硬件编码（MediaCodec）", style = MaterialTheme.typography.bodyMedium)
                        Text("H.264 / H.265 使用设备硬件编码器；CRF 与 x264/x265 的 preset 不直接适用，这里会根据 CRF 自动换算视频码率。", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                    Text("质量控制（CRF）：${state.crf}", style = MaterialTheme.typography.bodyMedium)
                    Text("CRF 越小：画质越高、文件越大；CRF 越大：画质越低、文件越小。16～30 可调，23 是常用的平衡值。", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    Slider(value = state.crf.toFloat(), onValueChange = { onStateChange(state.copy(crf = it.toInt())) }, valueRange = 16f..30f, steps = 13)
                    if (state.codec != "H.264 / AVC" && state.codec != "H.265 / HEVC") {
                        Text("编码速度：${presetLabel(state.preset)}")
                        Dropdown(presetLabel(state.preset), listOf("极快（ultrafast）","较快（fast）","平衡（medium）","较慢（slow）","极慢（veryslow）")) { onStateChange(state.copy(preset = it.substringAfter("（").substringBefore("）"))) }
                    }
                    Text("音频码率：${state.bitrate} kbps")
                    Dropdown("${state.bitrate} kbps", listOf("96 kbps","128 kbps","160 kbps","192 kbps","256 kbps")) { onStateChange(state.copy(bitrate = it.substringBefore(' ').toInt())) }
                    Text("视频里的声音会重新编码为 AAC。码率越高，音质通常越好，同时文件也会更大。", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
                Text("实际 FFmpeg 参数：${videoCodecLabel(state.codec)} · 输出 .${state.videoExt} · ${when (state.codec) {
                    "H.264 / AVC" -> "-c:v h264_mediacodec -codec_name 自动选择 -bitrate_mode vbr -b:v 自动计算 -g 120 -pix_fmt nv12 -c:a aac"
                    "H.265 / HEVC" -> "-c:v hevc_mediacodec -codec_name 自动选择 -bitrate_mode vbr -b:v 自动计算 -g 120 -pix_fmt nv12 -c:a aac"
                    "复制原视频流" -> "-c:v copy -c:a copy"
                    else -> "-crf ${state.crf} -速度 ${presetLabel(state.preset)} -c:a aac -b:a ${state.bitrate}k"
                }}", style = MaterialTheme.typography.bodySmall)
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("已选 ${files.size} 个文件", style = MaterialTheme.typography.titleMedium)
                    Text("并行：${parallelLabel(settings.parallel)}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
                if (files.isNotEmpty()) {
                    TextButton(onClick = {
                        if (mode == "视频") onStateChange(state.copy(videoFiles = emptyList(), selectedVideoIndex = 0))
                        else onStateChange(state.copy(audioFiles = emptyList()))
                    }) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("清除")
                    }
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                files.forEachIndexed { idx, file ->
                    val done = completed.value.contains(idx)
                    val activeFile = currentIndex.value == idx && (running.value || paused.value)
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (done) "✓" else if (activeFile) "▶" else "•", color = if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(28.dp))
                        Text(file.name, Modifier.weight(1f), maxLines = 1)
                        if (done) Text("转换成功", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                        else if (activeFile) Text("${currentFileProgress.value}%", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                        IconButton(
                            onClick = {
                                if (mode == "视频") {
                                    val newFiles = state.videoFiles.toMutableList().apply { removeAt(idx) }
                                    val newIndex = when {
                                        newFiles.isEmpty() -> 0
                                        state.selectedVideoIndex > idx -> state.selectedVideoIndex - 1
                                        state.selectedVideoIndex >= newFiles.size -> newFiles.lastIndex
                                        else -> state.selectedVideoIndex
                                    }
                                    onStateChange(state.copy(videoFiles = newFiles, selectedVideoIndex = newIndex))
                                } else {
                                    onStateChange(state.copy(audioFiles = state.audioFiles.toMutableList().apply { removeAt(idx) }))
                                }
                            },
                            modifier = Modifier.size(38.dp)
                        ) { Icon(Icons.Default.Close, contentDescription = "删除 ${file.name}") }
                    }
                }
            }
        }
        if (files.isNotEmpty() && outputTree != null && !running.value && !paused.value) {
            Button(
                onClick = {
                    val task = if (mode == "音频") {
                        TaskData("audio", "WRZ Media · 音频转换", files.map { it.uri.toString() }, files.map { it.name }, outputTree.toString(), state.audioExt, state.bitrate, parallel = settings.parallel)
                    } else {
                        TaskData("video", "WRZ Media · 视频转换", files.map { it.uri.toString() }, files.map { it.name }, outputTree.toString(), bitrate = state.bitrate, videoCodec = state.codec, videoExt = state.videoExt, crf = state.crf, preset = state.preset, parallel = settings.parallel)
                    }
                    onStartTask(task)
                },
                modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 20.dp, vertical = 8.dp).fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                contentPadding = PaddingValues(vertical = 15.dp)
            ) { Text("开始转换") }
        }
    }
}

@Composable
private fun TaskCard(progress: State<Int>, text: State<String>, running: State<Boolean>, paused: State<Boolean>, finished: State<Boolean>, error: State<Boolean>, onPauseTask: () -> Unit, onResumeTask: () -> Unit, onDismissTask: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var expanded by remember { mutableStateOf(false) }
    LaunchedEffect(error.value) { if (error.value) expanded = true }
    val shape = RoundedCornerShape(24.dp)
    Surface(modifier = modifier.fillMaxWidth().animateContentSize(), shape = shape, tonalElevation = 0.dp, shadowElevation = 0.dp, color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.98f)) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    val title = when {
                        error.value -> "转换失败 · ${progress.value}%"
                        paused.value -> "已暂停 · ${progress.value}%"
                        else -> "后台转换 · ${progress.value}%"
                    }
                    Text(title, style = MaterialTheme.typography.titleSmall)
                    LinearProgressIndicator({ progress.value.coerceIn(0, 100) / 100f }, Modifier.fillMaxWidth().padding(top = 5.dp))
                }
                if (finished.value && error.value) {
                    IconButton(onClick = onDismissTask) { Icon(Icons.Default.Close, contentDescription = "关闭错误") }
                }
                TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "收起" else "展开") }
            }
            AnimatedVisibility(expanded) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                    Text(
                        text.value.ifBlank { if (paused.value) "已保存断点，继续后从未完成文件恢复" else "正在后台转换…" },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (error.value) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                        maxLines = 8
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        if (running.value) Button(onClick = onPauseTask, modifier = Modifier.weight(1f)) { Text("暂停") }
                        else if (paused.value) Button(onClick = onResumeTask, modifier = Modifier.weight(1f)) { Text("继续") }
                        if (!finished.value) OutlinedButton(onClick = { MediaProcessingService.cancel(context) }, modifier = Modifier.weight(1f)) { Text("取消任务") }
                    }
                }
            }
        }
    }
}

@Composable
private fun MergePage(progress: State<Int>, progressText: State<String>, running: State<Boolean>, paused: State<Boolean>, taskMode: State<String>, settings: AppSettings, modifier: Modifier, onStartTask: (TaskData) -> Unit) {
    val context = LocalContext.current; var video by remember { mutableStateOf<MediaFile?>(null) }; var audio by remember { mutableStateOf<MediaFile?>(null) }; var output by remember { mutableStateOf<Uri?>(null) }; var bitrate by remember(settings.defaultBitrate) { mutableIntStateOf(settings.defaultBitrate) }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let { video = makeMediaFile(context, it, true) } }; val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let { audio = makeMediaFile(context, it, false) } }; val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let { persist(context, it); output = it } }
    val active = taskMode.value == "merge"
    Column(modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("音视频合并", style = MaterialTheme.typography.headlineSmall)
        OutlinedButton(onClick = { videoPicker.launch(arrayOf("video/*")) }, Modifier.fillMaxWidth()) { Text("视频：${video?.name ?: "选择视频"}") }
        OutlinedButton(onClick = { audioPicker.launch(arrayOf("audio/*")) }, Modifier.fillMaxWidth()) { Text("音频：${audio?.name ?: "选择音频"}") }
        OutlinedButton(onClick = { folderPicker.launch(null) }, Modifier.fillMaxWidth()) { Text("输出目录：${if (output == null) "选择" else "已选择"}") }
        Dropdown("AAC ${bitrate} kbps", listOf("96 kbps","128 kbps","160 kbps","192 kbps","256 kbps")) { bitrate = it.substringBefore(' ').toInt() }
        Text("视频流默认 copy，不重新压缩；音频重新编码为 AAC。", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(enabled = video != null && audio != null && output != null && (!running.value || !active), onClick = { onStartTask(TaskData("merge", "WRZ Media · 音视频合并", listOf(video!!.uri.toString(), audio!!.uri.toString()), listOf(video!!.name, audio!!.name), output.toString(), bitrate = bitrate, mergeName = video!!.name.substringBeforeLast('.') + "_merged.mp4", parallel = settings.parallel)) }, modifier = Modifier.fillMaxWidth()) { Text(if (active && running.value) "合并中… ${progress.value}%" else if (active && paused.value) "已暂停 · 继续合并" else "开始合并") }
    }
}

@Composable
private fun SettingsPage(settings: AppSettings, onChange: (AppSettings) -> Unit, modifier: Modifier) {
    Column(modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("设置", style = MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text("WRZ Media 2.0", style = MaterialTheme.typography.titleLarge); Text("本地 FFmpeg · Android 原生界面 · 无上传", color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        SettingDropdown("并行转换任务", parallelLabel(settings.parallel), listOf("自动", "1 路", "2 路", "3 路", "4 路", "6 路", "8 路")) { v -> onChange(settings.copy(parallel = if (v == "自动") 0 else v.substringBefore(' ').toInt())) }
        SettingDropdown("默认音频码率", "${settings.defaultBitrate} kbps", listOf("96 kbps","128 kbps","160 kbps","192 kbps","224 kbps","256 kbps","320 kbps")) { onChange(settings.copy(defaultBitrate = it.substringBefore(' ').toInt())) }
        SettingDropdown("外观", when(settings.darkMode) { 1 -> "深色"; 2 -> "浅色"; else -> "跟随系统" }, listOf("跟随系统","深色","浅色")) { onChange(settings.copy(darkMode = when(it) { "深色" -> 1; "浅色" -> 2; else -> 0 })) }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("转换时保持屏幕常亮"); Text("只在前台查看设置时有用，后台任务仍由前台服务维持", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall) }; Switch(settings.keepScreen, { onChange(settings.copy(keepScreen = it)) }) }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text("后台任务", style = MaterialTheme.typography.titleMedium); Text("暂停会保存已完成文件的索引；继续时从未完成的文件开始。当前正在转换的那个文件如果暂停，会重新处理该文件。", color = MaterialTheme.colorScheme.onSurfaceVariant); Text("极客模式：可手动开到 8 路并行。路数越高，CPU、内存占用越高；视频软件编码尤其吃 CPU。", color = MaterialTheme.colorScheme.onSurfaceVariant) } }
    }
}

@Composable private fun SettingDropdown(title: String, value: String, options: List<String>, onPick: (String) -> Unit) { Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title); Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Dropdown(value, options, onPick) } } }
private fun parallelLabel(v: Int) = if (v == 0) "自动" else "$v 路"

@Composable private fun VideoPreview(uri: Uri) {
    val context = LocalContext.current
    val player = remember(uri.toString()) {
        ExoPlayer.Builder(context).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            volume = 1f
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = false
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { PlayerView(it).apply { useController = true; controllerAutoShow = true } },
        update = { view -> view.player = player },
        modifier = Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(18.dp))
    )
}
@Composable private fun InfoCard(info: MediaInfo) { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) { Text("原始媒体参数", style = MaterialTheme.typography.titleMedium); Text("文件：${info.size} · 时长：${info.duration} · MIME：${info.mime}"); Text("视频：${info.videoCodec} · ${info.width}×${info.height} · ${info.fps} FPS"); Text("音频：${info.audioCodec} · ${info.audioRate}") } } }
@Composable private fun Dropdown(value: String, options: List<String>, onPick: (String) -> Unit) { var expanded by remember { mutableStateOf(false) }; Box { OutlinedButton(onClick = { expanded = true }) { Text(value); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(expanded, { expanded = false }) { options.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { onPick(it); expanded = false }) } } } }

private fun scanFolder(context: Context, treeUri: Uri, video: Boolean): List<MediaFile> { val root = DocumentFile.fromTreeUri(context, treeUri) ?: return emptyList(); val result = mutableListOf<MediaFile>(); fun walk(dir: DocumentFile) { dir.listFiles().forEach { file -> if (file.isDirectory) walk(file) else if (file.isFile) makeMediaFile(context, file.uri, video)?.let { result += it } } }; walk(root); return result }
private fun makeMediaFile(context: Context, uri: Uri, video: Boolean): MediaFile? { val name = displayName(context, uri) ?: return null; val ext = name.substringAfterLast('.', "").lowercase(Locale.US); if (video && ext !in VIDEO_EXT) return null; if (!video && ext !in AUDIO_EXT) return null; return MediaFile(uri, name, video) }
private fun displayName(context: Context, uri: Uri): String? = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
private fun persist(context: Context, uri: Uri) { try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {} }
private fun readInfo(context: Context, uri: Uri): MediaInfo { val r = MediaMetadataRetriever(); try { r.setDataSource(context, uri); val size = context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c -> if (c.moveToFirst()) c.getLong(0) else 0L } ?: 0L; val duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.let { formatDuration(it) } ?: "未知"; val mime = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: "未知"; val v = findTrackMime(context, uri, true); val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH) ?: "?"; val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT) ?: "?"; val fps = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE) ?: "?"; val a = findTrackMime(context, uri, false); val ar = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE) ?: "未知"; return MediaInfo(formatSize(size), duration, mime, v, w, h, fps, a, if (ar == "未知") ar else "${ar.toLongOrNull()?.div(1000) ?: ar} kbps") } finally { r.release() } }
private fun findTrackMime(context: Context, uri: Uri, video: Boolean): String { val extractor = android.media.MediaExtractor(); return try { extractor.setDataSource(context, uri, null); val prefix = if (video) "video/" else "audio/"; var result = "未知"; for (i in 0 until extractor.trackCount) { val mime = extractor.getTrackFormat(i).getString(android.media.MediaFormat.KEY_MIME) ?: continue; if (mime.startsWith(prefix)) { result = mime.substringAfter('/'); break } }; result } catch (_: Exception) { "未知" } finally { extractor.release() } }
private fun formatSize(bytes: Long): String = when { bytes < 1024 -> "$bytes B"; bytes < 1024*1024 -> "%.1f KB".format(bytes/1024.0); bytes < 1024*1024*1024 -> "%.1f MB".format(bytes/1024.0/1024); else -> "%.2f GB".format(bytes/1024.0/1024/1024) }
private fun formatDuration(ms: Long): String { val s = ms / 1000; return "%02d:%02d:%02d".format(s/3600, (s%3600)/60, s%60) }
